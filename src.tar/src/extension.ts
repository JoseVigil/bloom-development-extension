// src/extension.ts
import * as vscode from 'vscode';
import { Logger } from './utils/logger';
import { initializeContext } from './initialization/contextInitializer';
import { initializeProviders } from './initialization/providersInitializer';
import { initializeManagers } from './initialization/managersInitializer';
import { registerAllCommands } from './initialization/commandRegistry';
import { registerCriticalCommands } from './initialization/criticalCommandsInitializer';

export function activate(context: vscode.ExtensionContext) {
    const logger = new Logger();
    logger.info('🌸 Bloom BTIP + Nucleus Premium activando...');

    try {
        // 1. Inicializar contexto global
        const isRegistered = initializeContext(context, logger);
        
        // 2. Inicializar managers
        const managers = initializeManagers(context, logger);
        
        // 3. Verificar workspace
        const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
        
        if (!workspaceFolder) {
            logger.warn('⚠️ No workspace folder - Limited functionality');
            registerCriticalCommands(context, logger, managers.welcomeView);
            return;
        }
        
        // 4. Inicializar providers
        const providers = initializeProviders(context, workspaceFolder, logger, managers);
        
        // 5. Registrar TODOS los comandos
        registerAllCommands(context, logger, managers, providers);
        
        // 6. Mostrar welcome si es primera vez
        if (!isRegistered) {
            logger.info('📋 Primera instalación - Mostrando Welcome');
            setTimeout(() => {
                try {
                    managers.welcomeView.show();
                } catch (error: any) {
                    logger.error('Error showing welcome', error);
                }
            }, 1000);
        }
        
        logger.info('✅ Bloom BTIP activation complete');
        
    } catch (error: any) {
        logger.error('❌ Critical error during activation', error);
        vscode.window.showErrorMessage(
            `Bloom BTIP falló al activarse: ${error.message}`
        );
    }
}

export function deactivate() {
    // VSCode limpia automáticamente
}