// File: internal/supervisor/logs.go
// Categoría: SUPERVISOR
// Sigue Guía Maestra de Implementación Comandos NUCLEUS v2.0
//
// Comandos implementados:
//   nucleus logs <stream> [--since Xm/Xh] [--errors-only] [--no-startup] [--tail]
//   nucleus logs --launch <launch_id> [--profile <profile_id>] [--out <file>]
//   nucleus logs --summary [--since Xm]
//   nucleus logs synapse
//     Lista perfiles disponibles vía Brain CLI, toma el último launch_id del
//     perfil elegido y ejecuta automáticamente el trace completo de logs.
package supervisor

import (
	"bufio"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"

	"nucleus/internal/core"

	"github.com/spf13/cobra"
)

func init() {
	core.RegisterCommand("SUPERVISOR", createLogsCommand)
}

// outputJSON serializes v to indented JSON and writes it to stdout.
func outputJSON(v interface{}) {
	enc := json.NewEncoder(os.Stdout)
	enc.SetIndent("", "  ")
	_ = enc.Encode(v)
}

// ── telemetry.json structures ─────────────────────────────────────────────────

type telemetryFile struct {
	ActiveStreams map[string]telemetryStream `json:"active_streams"`
}

type telemetryStream struct {
	Path        string   `json:"path"`
	Label       string   `json:"label,omitempty"`
	Priority    int      `json:"priority,omitempty"`
	Categories  []string `json:"categories"`
	Description string   `json:"description,omitempty"`
	Source      string   `json:"source,omitempty"`
	FirstSeen   string   `json:"first_seen,omitempty"`
	LastUpdate  string   `json:"last_update,omitempty"`
	Active      bool     `json:"active,omitempty"`
}

// ── startup noise patterns (Brain CLI) ───────────────────────────────────────

var startupNoisePatterns = []string{
	"_setup_specialized_namespaces",
	"SPECIALIZED LOGGER INITIALIZED",
	"Log File:",
	"Propagate to root:",
	"Telemetry registered:",
}

func isStartupNoise(line string) bool {
	for _, p := range startupNoisePatterns {
		if strings.Contains(line, p) {
			return true
		}
	}
	// Separator lines
	trimmed := strings.TrimSpace(line)
	if strings.Count(trimmed, "=") == len(trimmed) && len(trimmed) > 3 {
		return true
	}
	if strings.Count(trimmed, "-") == len(trimmed) && len(trimmed) > 3 {
		return true
	}
	return false
}

// ── time helpers ──────────────────────────────────────────────────────────────

// parseSinceDuration parses "5m", "2h", "30s" into a time.Duration.
func parseSinceDuration(since string) (time.Duration, error) {
	since = strings.TrimSpace(strings.ToLower(since))
	if since == "" {
		return 0, nil
	}
	// Try Go native format first (e.g. "5m", "2h30m")
	if d, err := time.ParseDuration(since); err == nil {
		return d, nil
	}
	// Accept shorthand like "5m", "2h" without explicit unit suffix already handled above
	return 0, fmt.Errorf("invalid duration %q — use formats like 5m, 2h, 30s", since)
}

// parseLineTimestamp tries to extract a timestamp from a log line.
//
// Handles several layouts found across Bloom log streams:
//
//  1. Go logger prefix (nucleus, sentinel):
//     "2006/01/02 15:04:05 ..."
//
//  2. Brain Python logger (ISO8601, no brackets):
//     "2006-01-02T15:04:05.000Z ..."
//
//  3. Conductor / Electron installer (ISO8601 in brackets):
//     "[2006-01-02T15:04:05.000Z] ..."
//     "[2006-01-02T15:04:05Z] ..."
//
//  4. Sentinel stdout wrapper (bracketed space-separated, local time):
//     "[2006-01-02 15:04:05] [stdout] ..."
//
//  5. Chromium engine log (MMDD/HHMMss.mmm inside square-bracket process header):
//     "[PID:TID:MMDD/HHMMss.mmm:LEVEL:source] ..."
//     e.g. "[14012:19908:0223/000150.567:VERBOSE1:...]"
//     Month+day = 0223 → Feb 23; time = 000150.567 → 00:01:50.567
//     The year is inferred from the current UTC year since Chromium omits it.
//
//  6. SynapseSimulator banner (timestamp bracketed inline, not at line start):
//     "======== [2006-01-02T15:04:05Z] SynapseSimulator session started ..."
//
//  7. Pino/nucleus_control_plane JSON logger (epoch milliseconds in "time" field):
//     {"level":30,"time":1780841595866,"msg":"..."}
//
// Returns zero time on failure.
func parseLineTimestamp(line string) time.Time {
	if len(line) < 10 {
		return time.Time{}
	}

	// ── Priority 1: Chromium process-header format ────────────────────────────
	// Pattern: [...:MMDD/HHMMss.mmm:...] at any position in the line.
	// We scan every '/' looking for one where the 4 chars before it are all
	// digits (MMDD) AND the char before those 4 digits is ':' or '['.
	// This avoids false matches on file-system paths that also contain '/'.
	{
		allDigits := func(s string) bool {
			for _, c := range s {
				if c < '0' || c > '9' {
					return false
				}
			}
			return len(s) > 0
		}

		searchFrom := 0
		for {
			idx := strings.Index(line[searchFrom:], "/")
			if idx < 0 {
				break
			}
			idx += searchFrom // absolute index in line

			start := idx - 4
			// Need at least 4 digits before '/' and 10 chars after (HHMMss.mmm)
			minEnd := idx + 1 + 10
			if start < 0 || minEnd > len(line) {
				searchFrom = idx + 1
				continue
			}

			part1 := line[start:idx]        // MMDD
			part2 := line[idx+1 : idx+1+6]  // HHMMss

			// Must be all digits and preceded by ':' or '['
			if allDigits(part1) && allDigits(part2) &&
				(line[start-1] == ':' || line[start-1] == '[') {

				// Grab milliseconds if present: HHMMss.mmm
				fullEnd := idx + 1 + 10 // points at char after 'mmm'
				var msStr string
				if fullEnd <= len(line) && line[idx+1+6] == '.' {
					msStr = line[idx+1+7 : fullEnd]
					if !allDigits(msStr) {
						msStr = "000"
					}
				} else {
					msStr = "000"
				}

				month := part1[0:2]
				day := part1[2:4]
				hour := part2[0:2]
				min := part2[2:4]
				sec := part2[4:6]
				year := time.Now().UTC().Year()
				synthetic := fmt.Sprintf("%d-%s-%sT%s:%s:%s.%sZ", year, month, day, hour, min, sec, msStr)
				if t, err := time.Parse("2006-01-02T15:04:05.000Z", synthetic); err == nil {
					return t
				}
			}

			searchFrom = idx + 1
		}
	}

	// ── Priority 1b: Windows batch/cmd timestamp ─────────────────────────────
	// Format emitted by build scripts via %DATE% %TIME%:
	//   "Mon 02/23/2026  1:46:42.71 ..."
	//   "Build Log - Mon 02/23/2026  1:46:42.71"
	// Day-of-week prefix (3 chars + space) is skipped; we parse MM/DD/YYYY HH:MM:SS.
	{
		line := strings.TrimSpace(line)
		// Strip optional label prefix up to " - " (e.g. "Build Log - ")
		if di := strings.Index(line, " - "); di >= 0 {
			line = strings.TrimSpace(line[di+3:])
		}
		// Expect: "Mon MM/DD/YYYY  H:MM:SS.cc" or "Mon MM/DD/YYYY HH:MM:SS.cc"
		// Day-of-week is 3 chars + space = 4 chars prefix.
		if len(line) >= 4 {
			rest := line[4:] // skip "Mon "
			// rest = "MM/DD/YYYY  H:MM:SS.cc" or "MM/DD/YYYY HH:MM:SS.cc"
			// Find the space(s) between date and time
			slashCount := 0
			dateEnd := -1
			for i, c := range rest {
				if c == '/' {
					slashCount++
				}
				if slashCount == 2 && c == ' ' {
					dateEnd = i
					break
				}
			}
			if dateEnd > 0 {
				datePart := rest[:dateEnd]                      // "MM/DD/YYYY"
				timePart := strings.TrimSpace(rest[dateEnd+1:]) // "H:MM:SS.cc ..."
				// Take only the time token (up to first space)
				if sp := strings.Index(timePart, " "); sp >= 0 {
					timePart = timePart[:sp]
				}
				// Strip centiseconds/milliseconds suffix (.cc or .ccc)
				if dot := strings.LastIndex(timePart, "."); dot >= 0 {
					timePart = timePart[:dot]
				}
				// Zero-pad single-digit hour: "1:46:42" → "01:46:42"
				if len(timePart) > 0 && timePart[1] == ':' {
					timePart = "0" + timePart
				}
				combined := datePart + " " + timePart // "02/23/2026 01:46:42"
				if t, err := time.ParseInLocation("01/02/2006 15:04:05", combined, time.Local); err == nil {
					return t
				}
			}
		}
	}
	// ── Priority 1c: Host / Cortex session banner ────────────────────────────
	// Format: "===== HOST SESSION 2026-03-04 04:48:55.764 UTC PID:... ====="
	//         "===== EXTENSION SESSION 2026-03-04 04:48:55.764 UTC PID:... ====="
	// The timestamp "YYYY-MM-DD HH:MM:SS.mmm" appears right after the keyword SESSION.
	{
		const sessionKeyword = " SESSION "
		if idx := strings.Index(line, sessionKeyword); idx >= 0 {
			rest := strings.TrimSpace(line[idx+len(sessionKeyword):])
			// rest starts with "2026-03-04 04:48:55.764 UTC ..."
			// Try "2006-01-02 15:04:05.000" (23 chars) then strip " UTC"
			if len(rest) >= 23 {
				candidate := rest[:23]
				if t, err := time.ParseInLocation("2006-01-02 15:04:05.000", candidate, time.UTC); err == nil {
					return t
				}
			}
			// Fallback: without milliseconds "2006-01-02 15:04:05" (19 chars)
			if len(rest) >= 19 {
				candidate := rest[:19]
				if t, err := time.ParseInLocation("2006-01-02 15:04:05", candidate, time.UTC); err == nil {
					return t
				}
			}
		}
	}

	// Formats that include an explicit timezone offset (Z or ±HH:MM) are parsed
	// as-is via time.Parse — the offset is self-describing.
	// Formats WITHOUT an explicit offset (Go logger, plain ISO) are written by
	// Go's log package using local time, so we use time.ParseInLocation(Local).
	type tsFormat struct {
		format   string
		length   int
		hasZone  bool // true = offset embedded, false = treat as local
	}
	formats := []tsFormat{
		// Bracketed ISO8601 with milliseconds: [2026-02-23T02:08:37.849Z]
		{"[2006-01-02T15:04:05.000Z]", 26, true},
		// Bracketed ISO8601 no ms with Z: [2026-02-23T01:52:05Z]
		// NOTE: build_all writes local time but appends a literal 'Z' (script bug).
		// We use a sentinel hasZone value (2) handled below to strip the zone and
		// reinterpret the wall clock as local.
		{"[2006-01-02T15:04:05Z]", 22, false},
		// Bracketed ISO8601 with offset: [2026-02-23T02:08:37.849-03:00]
		{"[2006-01-02T15:04:05.000Z07:00]", 31, true},
		// BUG 1 FIX — Sentinel stdout wrapper: [2026-06-07 11:13:34] [stdout] ...
		// The bracket format with space-separated date was missing from the table.
		// hasZone=false: wall clock reinterpreted as local time (Argentina).
		{"[2006-01-02 15:04:05]", 21, false},
		// Plain ISO8601 with milliseconds: 2026-02-23T02:08:37.849Z
		{"2006-01-02T15:04:05.000Z", 24, true},
		// Plain ISO8601 with ms and offset: 2026-02-23T02:08:37.849+00:00
		{"2006-01-02T15:04:05.000Z07:00", 29, true},
		// Plain ISO8601 no ms: 2026-02-22T23:08:19Z
		{"2006-01-02T15:04:05Z", 20, true},
		// Plain ISO8601 with offset no ms: 2026-02-22T23:08:19-03:00
		{"2006-01-02T15:04:05Z07:00", 25, true},
		// Go logger: 2026/02/22 23:08:19  — LOCAL time, no zone info
		{"2006/01/02 15:04:05", 19, false},
		// Space-separated date: 2026-02-22 23:08:19  — LOCAL time, no zone info
		{"2006-01-02 15:04:05", 19, false},
		// Plain ISO8601 no ms no Z: 2026-02-22T23:08:19  — LOCAL time, no zone info
		{"2006-01-02T15:04:05", 19, false},
	}

	candidate := strings.TrimSpace(line)

	tryFormats := func(s string) time.Time {
		for _, e := range formats {
			if len(s) >= e.length {
				substr := s[:e.length]
				var t time.Time
				var err error
				if e.hasZone {
					t, err = time.Parse(e.format, substr)
				} else {
					// hasZone=false: the format may contain a literal 'Z' in the layout
					// (e.g. build_all writes local time with a bogus 'Z' suffix).
					// Parse it with time.Parse to accept the Z, then reinterpret the
					// wall-clock components as local time — discarding the false UTC offset.
					var parsed time.Time
					parsed, err = time.Parse(e.format, substr)
					if err == nil {
						// Re-parse wall clock in local timezone
						t, err = time.ParseInLocation(
							"2006-01-02 15:04:05",
							parsed.Format("2006-01-02 15:04:05"),
							time.Local,
						)
					}
				}
				if err == nil {
					return t
				}
			}
		}
		return time.Time{}
	}

	// First attempt: match from the start of the (trimmed) line.
	if t := tryFormats(candidate); !t.IsZero() {
		return t
	}

	// BUG 2 FIX — SynapseSimulator banner: "======== [2026-06-07T14:12:54Z] SynapseSimulator session ..."
	// The timestamp is bracketed but NOT at the start of the line, so the
	// formats table never matched it.  Find the first '[' and re-run the
	// format search against the substring starting there.
	if idx := strings.Index(candidate, "["); idx > 0 {
		if t := tryFormats(candidate[idx:]); !t.IsZero() {
			return t
		}
	}

	// BUG 3 FIX — Pino / nucleus_control_plane JSON logger.
	// Lines look like: {"level":30,"time":1780841595866,"pid":...,"msg":"..."}
	// The "time" field is Unix epoch in milliseconds.
	if strings.HasPrefix(candidate, "{") {
		const timeKey = `"time":`
		if idx := strings.Index(candidate, timeKey); idx >= 0 {
			rest := candidate[idx+len(timeKey):]
			// Extract the numeric value (digits only, no quotes)
			end := 0
			for end < len(rest) && rest[end] >= '0' && rest[end] <= '9' {
				end++
			}
			if end >= 10 { // at least 10 digits → plausible epoch
				if ms, err := strconv.ParseInt(rest[:end], 10, 64); err == nil {
					// Distinguish seconds (10 digits) from milliseconds (13 digits)
					var t time.Time
					if end <= 11 {
						// Unix seconds
						t = time.Unix(ms, 0).UTC()
					} else {
						// Unix milliseconds
						t = time.Unix(ms/1000, (ms%1000)*int64(time.Millisecond)).UTC()
					}
					return t
				}
			}
		}
	}

	return time.Time{}
}

// ── telemetry loader ──────────────────────────────────────────────────────────

func loadTelemetry(logsDir string) (*telemetryFile, error) {
	path := filepath.Join(logsDir, "telemetry.json")
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("cannot read telemetry.json: %w", err)
	}
	var tf telemetryFile
	if err := json.Unmarshal(data, &tf); err != nil {
		return nil, fmt.Errorf("invalid telemetry.json: %w", err)
	}
	return &tf, nil
}


// ── stream reader ─────────────────────────────────────────────────────────────

type streamReadOptions struct {
	since      time.Duration
	errorsOnly bool
	noStartup  bool
	prefix     string
}

// readStream reads lines from a log file applying filters. Returns filtered lines.
// If the file does not exist, returns an empty slice (stream inactive).
func readStream(path string, opts streamReadOptions) ([]string, error) {
	f, err := os.Open(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil // inactive stream
		}
		return nil, err
	}
	defer f.Close()

	var cutoff time.Time
	if opts.since > 0 {
		cutoff = time.Now().Add(-opts.since)
	}

	var result []string
	scanner := bufio.NewScanner(f)
	scanner.Buffer(make([]byte, 1024*1024), 1024*1024)
	for scanner.Scan() {
		line := scanner.Text()

		if opts.noStartup && isStartupNoise(line) {
			continue
		}

		if opts.errorsOnly {
			upper := strings.ToUpper(line)
			if !strings.Contains(upper, "WARNING") && !strings.Contains(upper, "ERROR") {
				continue
			}
		}

		if !cutoff.IsZero() {
			ts := parseLineTimestamp(line)
			if !ts.IsZero() && ts.Before(cutoff) {
				continue
			}
		}

		if opts.prefix != "" {
			result = append(result, fmt.Sprintf("[%s] %s", opts.prefix, line))
		} else {
			result = append(result, line)
		}
	}
	return result, scanner.Err()
}

// readStreamWindow reads lines within [start, end] time window.
// Lines without a parseable timestamp are treated as continuation lines
// (e.g. stack trace frames, context blocks) and inherit the timestamp of
// the most recently seen timestamped line in the same file.  Only if no
// timestamped anchor has been seen yet do we include them unconditionally,
// so that file-level headers are not silently dropped.
//
// Returns []timedLine with the resolved timestamp already set (including the
// sticky timestamp for continuation lines), so callers don't need to re-parse
// and the inherited timestamp is not lost.
func readStreamWindow(path string, start, end time.Time, noStartup bool) []timedLine {
	f, err := os.Open(path)
	if err != nil {
		return nil
	}
	defer f.Close()

	var result []timedLine
	var stickyTS time.Time // last known timestamp for continuation lines
	headerDone := false    // true once we've seen the first timestamped line

	scanner := bufio.NewScanner(f)
	scanner.Buffer(make([]byte, 1024*1024), 1024*1024)
	for scanner.Scan() {
		line := scanner.Text()
		if noStartup && isStartupNoise(line) {
			continue
		}
		ts := parseLineTimestamp(line)
		if ts.IsZero() {
			// Continuation / context line — use sticky timestamp for window check.
			if !headerDone {
				// Pre-first-timestamp headers (file banners, report metadata) — include always.
				// stickyTS is still zero here, which is fine: the render will show ??:??:??
				// only for true pre-header lines, not for stack traces mid-stream.
				result = append(result, timedLine{ts: stickyTS, text: line})
			} else if !stickyTS.IsZero() && !stickyTS.Before(start) && !stickyTS.After(end) {
				// Inherit the anchor timestamp so the render shows the right time.
				result = append(result, timedLine{ts: stickyTS, text: line})
			}
			// else: sticky is outside window, skip continuation line
			continue
		}
		// Timestamped line
		stickyTS = ts
		headerDone = true
		if !ts.Before(start) && !ts.After(end) {
			result = append(result, timedLine{ts: ts, text: line})
		}
	}
	return result
}

// readStreamFull reads all lines from a log file without any time filter.
// Used for streams that are dedicated to a single launch (the stream ID already
// contains the launch_id, so every line in the file belongs to that launch).
// Continuation lines without a timestamp inherit the last known timestamp,
// matching the same sticky-timestamp behaviour as readStreamWindow.
func readStreamFull(path string, noStartup bool) []timedLine {
	f, err := os.Open(path)
	if err != nil {
		return nil
	}
	defer f.Close()

	var result []timedLine
	var stickyTS time.Time

	scanner := bufio.NewScanner(f)
	scanner.Buffer(make([]byte, 1024*1024), 1024*1024)
	for scanner.Scan() {
		line := scanner.Text()
		if noStartup && isStartupNoise(line) {
			continue
		}
		ts := parseLineTimestamp(line)
		if ts.IsZero() {
			result = append(result, timedLine{ts: stickyTS, text: line})
			continue
		}
		stickyTS = ts
		result = append(result, timedLine{ts: ts, text: line})
	}
	return result
}

// ── Parent command ────────────────────────────────────────────────────────────

func createLogsCommand(c *core.Core) *cobra.Command {
	var (
		launchID  string
		profileID string
		outFile   string
		summary   bool
		since     string
		errOnly   bool
		noStartup bool
		tailMode  bool
		jsonOut   bool
	)

	cmd := &cobra.Command{
		Use:   "logs [stream]",
		Short: "Read, trace and analyze Nucleus log streams",
		Long: `Access and correlate logs across all Nucleus components.

Three modes of operation:

  1. STREAM READER — read a single named stream:
       nucleus logs nucleus_synapse --since 5m --errors-only

  2. SYNAPSE TRACE — full correlated trace for a launch:
       nucleus logs --launch 001_0b31f2fa_033803 --profile <uuid>
       Produces: logs/synapse/trace_<launch_id>.log

  3. SUMMARY — dashboard of all active streams:
       nucleus logs --summary --since 10m

Stream names come from the keys in telemetry.json (active_streams).`,

		Annotations: map[string]string{
			"category": "SUPERVISOR",
			"json_response": `{
  "success": true,
  "mode": "stream|launch|summary",
  "lines": 42,
  "output_file": "logs/synapse_trace/synapse_trace_001_0b31f2fa_033803.log"
}`,
		},

		Example: `  nucleus logs nucleus_synapse --since 5m
  nucleus logs sentinel_core --errors-only --no-startup
  nucleus logs --launch 001_0b31f2fa_033803 --profile 0b31f2fa-1463-4919-b63e-96db6e36744c
  nucleus logs --summary --since 10m
  nucleus --json logs --launch 001_0b31f2fa_033803 --profile 0b31f2fa-1463-4919-b63e-96db6e36744c`,

		RunE: func(cmd *cobra.Command, args []string) error {
			if c.IsJSON {
				jsonOut = true
			}

			// ── MODE DISPATCH ────────────────────────────────────────────

			switch {
			case launchID != "":
				return runLaunchTrace(c, launchID, profileID, outFile, jsonOut)

			case summary:
				return runSummary(c, since, jsonOut)

			case len(args) == 1:
				return runStreamReader(c, args[0], since, errOnly, noStartup, tailMode, jsonOut)

			default:
				return fmt.Errorf("specify a stream name, --launch <id>, or --summary\nRun 'nucleus logs --help' for usage")
			}
		},
	}

	// Flags
	cmd.Flags().StringVar(&launchID, "launch", "", "Launch ID to produce a full synapse trace")
	cmd.Flags().StringVar(&profileID, "profile", "", "Profile ID (required for Chrome log analysis with --launch)")
	cmd.Flags().StringVar(&outFile, "out", "", "Output file path (default: logs/synapse/trace_<launch_id>.log)")
	cmd.Flags().BoolVar(&summary, "summary", false, "Show dashboard of all streams")
	cmd.Flags().StringVar(&since, "since", "", "Only show lines from last X minutes/hours (e.g. 5m, 2h)")
	cmd.Flags().BoolVar(&errOnly, "errors-only", false, "Only show WARNING or ERROR lines")
	cmd.Flags().BoolVar(&noStartup, "no-startup", false, "Exclude Brain startup noise patterns")
	cmd.Flags().BoolVar(&tailMode, "tail", false, "Live tail mode (follow file)")
	cmd.Flags().BoolVar(&jsonOut, "json", false, "Output in JSON format")

	// Subcomandos
	cmd.AddCommand(createSynapseCommand(c))

	return cmd
}

// ═════════════════════════════════════════════════════════════════════════════
// SUBCOMMAND: nucleus logs synapse
// ─ Obtiene perfiles via Brain CLI, toma el último launch y corre el trace
// ═════════════════════════════════════════════════════════════════════════════

// brainProfileList representa la respuesta de `brain --json profile list`.
type brainProfileList struct {
	Status string `json:"status"`
	Data   struct {
		Profiles []brainProfile `json:"profiles"`
	} `json:"data"`
}

type brainProfile struct {
	ID           string `json:"id"`
	Alias        string `json:"alias"`
	LastLaunchID string `json:"last_launch_id"`
}

// brainLaunchList representa la respuesta de `brain --json profile launches <id>`.
type brainLaunchList struct {
	Status string `json:"status"`
	Data   struct {
		Launches []brainLaunch `json:"launches"`
	} `json:"data"`
}

type brainLaunch struct {
	LaunchID string `json:"launch_id"`
	TS       string `json:"ts"`
	Result   string `json:"result"`
	Status   string `json:"_status"`
}

func runBrainJSON(binDir string, dest interface{}, args ...string) error {
	brainExe := filepath.Join(binDir, "brain", "brain.exe")
	if _, err := os.Stat(brainExe); err != nil {
		brainExeUnix := filepath.Join(binDir, "brain", "brain")
		if _, errUnix := os.Stat(brainExeUnix); errUnix == nil {
			brainExe = brainExeUnix  // path absoluto, no depende del PATH
		} else {
			brainExe = "brain"  
		}
	}
	allArgs := append([]string{"--json"}, args...)
	out, err := exec.Command(brainExe, allArgs...).Output()
	if err != nil {
		return fmt.Errorf("brain %s: %w\noutput: %s", strings.Join(args, " "), err, string(out))
	}
	return json.Unmarshal(out, dest)
}

func createSynapseCommand(c *core.Core) *cobra.Command {
	return &cobra.Command{
		Use:   "synapse",
		Short: "Trace automático del último launch — obtiene perfil y launch_id via Brain CLI",
		Long: `Ejecuta automáticamente:
  1. brain profile list          → lista perfiles disponibles
  2. brain profile launches <id> → obtiene el último launch_id
  3. nucleus logs --launch <id> --profile <id>  → genera el trace completo

Si hay más de un perfil te pregunta cuál usar.`,
		Example: `  nucleus logs synapse`,
		RunE: func(cmd *cobra.Command, args []string) error {
			// En modo JSON (invocado por hook o CLI con --json) toda la narrativa
			// interactiva va a stderr para mantener stdout limpio para el JSON.
			// En modo terminal va a stdout como siempre.
			out := os.Stdout
			if c.IsJSON {
				out = os.Stderr
			}

			// ── Step 1: obtener perfiles ──────────────────────────────────────
			fmt.Fprintln(out, "� Obteniendo perfiles via Brain CLI...")
			var profileList brainProfileList
			if err := runBrainJSON(c.Paths.BinDir, &profileList, "profile", "list"); err != nil {
				return fmt.Errorf("no se pudo obtener la lista de perfiles: %w", err)
			}
			profiles := profileList.Data.Profiles
			if len(profiles) == 0 {
				return fmt.Errorf("no hay perfiles registrados en Brain CLI")
			}

			// ── Step 2: elegir perfil ─────────────────────────────────────────
			var chosen brainProfile
			if len(profiles) == 1 {
				chosen = profiles[0]
				fmt.Fprintf(out, "✅ Perfil: %s (%s)\n", chosen.Alias, chosen.ID)
			} else {
				fmt.Fprintln(out, "\nPerfiles disponibles:")
				for i, p := range profiles {
					fmt.Fprintf(out, "  [%d] %s — %s  (último launch: %s)\n", i+1, p.Alias, p.ID, p.LastLaunchID)
				}
				fmt.Fprint(out, "\nElegí un número: ")
				var sel int
				if _, err := fmt.Scan(&sel); err != nil || sel < 1 || sel > len(profiles) {
					return fmt.Errorf("selección inválida")
				}
				chosen = profiles[sel-1]
			}

			// ── Step 3: obtener último launch_id ──────────────────────────────
			fmt.Fprintf(out, "� Obteniendo launches del perfil %s...\n", chosen.Alias)
			var launchList brainLaunchList
			if err := runBrainJSON(c.Paths.BinDir, &launchList, "profile", "launches", chosen.ID); err != nil {
				return fmt.Errorf("no se pudo obtener los launches: %w", err)
			}
			launches := launchList.Data.Launches
			if len(launches) == 0 {
				return fmt.Errorf("el perfil %s no tiene launches registrados", chosen.Alias)
			}

			// El más reciente es el último de la lista
			last := launches[len(launches)-1]
			// Si last_launch_id ya está en el perfil lo usamos directamente
			launchID := chosen.LastLaunchID
			if launchID == "" {
				launchID = last.LaunchID
			}

			fmt.Fprintf(out, "✅ Launch ID: %s  (ts: %s, estado: %s)\n\n", launchID, last.TS, last.Status)

			// Parsear el timestamp del launch para evitar búsqueda en synapse log
			var launchTime time.Time
			if last.TS != "" {
				if t, err := time.Parse(time.RFC3339, last.TS); err == nil {
					launchTime = t
				} else if t, err := time.Parse("2006-01-02T15:04:05Z", last.TS); err == nil {
					launchTime = t
				}
			}

			// ── Step 4: correr el trace completo ──────────────────────────────
			fmt.Fprintln(out, "� Ejecutando trace completo de logs...")
			return runLaunchTrace(c, launchID, chosen.ID, "", c.IsJSON, launchTime)
		},
	}
}

// ═════════════════════════════════════════════════════════════════════════════
// MODE 1: STREAM READER
// ═════════════════════════════════════════════════════════════════════════════

func runStreamReader(c *core.Core, streamName, since string, errOnly, noStartup, tailMode, jsonOut bool) error {
	tf, err := loadTelemetry(c.Paths.LogsDir)
	if err != nil {
		return err
	}

	stream, ok := tf.ActiveStreams[streamName]
	if !ok {
		// List valid streams
		var valid []string
		for k := range tf.ActiveStreams {
			valid = append(valid, k)
		}
		sort.Strings(valid)
		return fmt.Errorf("unknown stream %q\n\nAvailable streams:\n  %s", streamName, strings.Join(valid, "\n  "))
	}

	var dur time.Duration
	if since != "" {
		dur, err = parseSinceDuration(since)
		if err != nil {
			return err
		}
	}

	opts := streamReadOptions{
		since:      dur,
		errorsOnly: errOnly,
		noStartup:  noStartup,
		prefix:     streamName,
	}

	// Live tail mode
	if tailMode {
		return tailStream(stream.Path, opts)
	}

	lines, err := readStream(stream.Path, opts)
	if err != nil {
		return fmt.Errorf("reading stream %s: %w", streamName, err)
	}

	if jsonOut {
		outputJSON(map[string]interface{}{
			"success":     true,
			"mode":        "stream",
			"stream":      streamName,
			"path":        stream.Path,
			"lines_count": len(lines),
			"lines":       lines,
		})
		return nil
	}

	if len(lines) == 0 {
		fmt.Printf("[%s] (no matching lines)\n", streamName)
		return nil
	}
	for _, l := range lines {
		fmt.Println(l)
	}
	return nil
}

// tailStream follows a file like tail -f.
func tailStream(path string, opts streamReadOptions) error {
	f, err := os.Open(path)
	if err != nil {
		return fmt.Errorf("cannot open %s: %w", path, err)
	}
	defer f.Close()

	// Seek to end
	if _, err := f.Seek(0, io.SeekEnd); err != nil {
		return err
	}

	reader := bufio.NewReader(f)
	fmt.Printf("Following %s (Ctrl+C to stop)\n\n", path)
	for {
		line, err := reader.ReadString('\n')
		if err != nil {
			if err == io.EOF {
				time.Sleep(200 * time.Millisecond)
				continue
			}
			return err
		}
		line = strings.TrimRight(line, "\r\n")
		if opts.noStartup && isStartupNoise(line) {
			continue
		}
		if opts.errorsOnly {
			upper := strings.ToUpper(line)
			if !strings.Contains(upper, "WARNING") && !strings.Contains(upper, "ERROR") {
				continue
			}
		}
		if opts.prefix != "" {
			fmt.Printf("[%s] %s\n", opts.prefix, line)
		} else {
			fmt.Println(line)
		}
	}
}

// ═════════════════════════════════════════════════════════════════════════════
// MODE 2: SYNAPSE TRACE — nucleus logs --launch <id>
// ═════════════════════════════════════════════════════════════════════════════

// launchedEvent holds parsed metadata from the synapse log for a launch.
type launchedEvent struct {
	timestamp time.Time
	raw       string
}

// findLaunchTimestamp scans nucleus_synapse log for the given launchID,
// returning the timestamp of its first mention.
func findLaunchTimestamp(synapseLogPath, launchID string) (time.Time, error) {
	f, err := os.Open(synapseLogPath)
	if err != nil {
		return time.Time{}, fmt.Errorf("cannot open synapse log %s: %w", synapseLogPath, err)
	}
	defer f.Close()

	scanner := bufio.NewScanner(f)
	scanner.Buffer(make([]byte, 1024*1024), 1024*1024)
	for scanner.Scan() {
		line := scanner.Text()
		if strings.Contains(line, launchID) {
			ts := parseLineTimestamp(line)
			if !ts.IsZero() {
				return ts, nil
			}
		}
	}
	return time.Time{}, fmt.Errorf("launch_id %q not found in %s", launchID, synapseLogPath)
}

// timedLine holds a log line with its parsed timestamp and origin stream.
type timedLine struct {
	ts     time.Time
	stream string
	text   string
}

// calculateWindowFromTelemetry calcula la ventana de captura del trace a partir
// del launchTS y los metadatos de telemetry.json.
//
// Regla:
//   - windowStart = launchTS - 30s  (fijo, no se expande hacia atrás)
//   - windowEnd   = max(launchTS+5m, last_update de streams activos en esta ventana + 1m)
//
// IMPORTANTE: el windowStart está anclado al launchTS y nunca se expande con
// first_seen de otros streams. Expandirlo causaba que logs de launches anteriores
// quedaran dentro de la ventana y se acumularan en el archivo de salida.
// Si los timestamps de telemetry no son parseables, se usa launchTS+5m como tope.
func calculateWindowFromTelemetry(tf *telemetryFile, launchTS time.Time) (time.Time, time.Time) {
	// Telemetry timestamps are written with time.Now().Format(time.RFC3339),
	// which uses the local timezone. We must parse them as local time so the
	// window aligns with the local timestamps written in log lines by Go's
	// log package (log.Ldate|log.Ltime, also local).
	parseLocal := func(s string) time.Time {
		// RFC3339 with explicit offset (e.g. "-03:00") — parse as-is, already correct.
		if t, err := time.Parse(time.RFC3339, s); err == nil {
			return t
		}
		// Fallback: no offset suffix — treat as local.
		for _, f := range []string{
			"2006-01-02T15:04:05",
			"2006-01-02T15:04:05.999999999",
			"2006-01-02 15:04:05",
		} {
			if t, err := time.ParseInLocation(f, s, time.Local); err == nil {
				return t
			}
		}
		return time.Time{}
	}

	// windowStart está FIJO: solo 30s antes del launch.
	// No se expande con first_seen de otros streams para evitar capturar
	// logs de launches anteriores.
	start := launchTS.Add(-30 * time.Second)
	end := launchTS.Add(5 * time.Minute)

	// Solo extendemos windowEnd con last_update de streams cuyo last_update
	// cae DENTRO de la ventana del launch (es decir, >= launchTS - margen).
	// Streams con last_update anterior al launch pertenecen a otro launch y
	// no deben influir en el windowEnd de este trace.
	for _, stream := range tf.ActiveStreams {
		lu := parseLocal(stream.LastUpdate)
		if lu.IsZero() {
			continue
		}
		// Solo considerar si el last_update ocurrió después del inicio del launch.
		// Streams que terminaron antes del launch son de un run anterior.
		if lu.Before(launchTS) {
			continue
		}
		// +1m de margen sobre el último evento registrado en telemetry
		candidate := lu.Add(1 * time.Minute)
		if candidate.After(end) {
			end = candidate
		}
	}

	// Sanidad: ventana mínima de 1 minuto
	if end.Before(start.Add(time.Minute)) {
		end = start.Add(time.Minute)
	}

	return start, end
}

// isLaunchDedicatedStream reports whether a stream is exclusively dedicated to
// a single launch. The telemetry convention is that such streams embed the
// launch_id (e.g. "005_cbc25063_090120") directly in the stream ID, so every
// line in the file belongs to that launch and no time-window filter is needed.
//
// Streams that are persistent across launches (brain_*, sentinel_core,
// nucleus_synapse, nucleus_orchestration, worker_manager, …) do NOT contain the
// launch_id in their stream ID and must be filtered by time window instead.
func isLaunchDedicatedStream(streamID, launchID string) bool {
	if launchID == "" {
		return false
	}
	return strings.Contains(streamID, launchID)
}

// isSessionDayStream reports whether a stream is a per-session or per-day file
// that started within the launch window and whose lines do NOT carry individual
// timestamps (e.g. conductor_onboarding, nucleus_control_plane, temporal_server,
// metamorph_*). These streams are safe to read in full because the file was
// created for this session; time-window filtering would silently drop all their
// lines since parseLineTimestamp returns zero for every line.
//
// Detection rule: first_seen is within [windowStart-2m, windowEnd] AND the
// stream is not a persistent cross-launch log (i.e. does not belong to the set
// of known accumulating streams).
func isSessionDayStream(streamID string, stream telemetryStream, windowStart, windowEnd time.Time) bool {
	// Persistent multi-launch streams — always filter by window, never read full.
	persistentPrefixes := []string{
		"brain_core", "brain_profile", "brain_server", "brain_service",
		"sentinel_core",
		"nucleus_synapse", "nucleus_orchestration", "nucleus_temporal",
		"nucleus_brain_poller", "worker_manager",
		"nucleus_hook_", // hooks accumulate across launches in the same day
		"nucleus_service",
	}
	for _, p := range persistentPrefixes {
		if strings.HasPrefix(streamID, p) {
			return false
		}
	}

	// Parse first_seen from telemetry. Telemetry writes RFC3339 (with offset),
	// so time.Parse handles it correctly regardless of local timezone.
	if stream.FirstSeen == "" {
		return false
	}
	var firstSeen time.Time
	if t, err := time.Parse(time.RFC3339, stream.FirstSeen); err == nil {
		firstSeen = t
	} else if t, err := time.Parse("2006-01-02T15:04:05.000Z", stream.FirstSeen); err == nil {
		firstSeen = t
	} else {
		return false
	}

	// Accept streams whose session started within a 2-minute look-back before
	// windowStart (covers race between telemetry registration and launch event)
	// and no later than windowEnd.
	return !firstSeen.Before(windowStart.Add(-2*time.Minute)) && !firstSeen.After(windowEnd)
}

// collectWindowLines collects lines from all streams for the given launch.
//
// Three strategies are applied depending on the stream type:
//
//  1. Launch-dedicated streams (stream ID contains launchID):
//     The file was created exclusively for this launch — read it completely.
//
//  2. Session-day streams (started within the launch window, lines lack timestamps):
//     Streams like conductor_onboarding, nucleus_control_plane, temporal_server,
//     and metamorph_* write report-style content without per-line timestamps.
//     readStreamWindow would silently drop all their lines (every ts = zero →
//     sticky anchor never set → only pre-header lines included, all with ??:??:??).
//     Instead we read them in full and stamp every line with first_seen so they
//     sort correctly in the unified timeline.
//
//  3. Persistent streams (brain_*, sentinel_core, nucleus_synapse, …):
//     These accumulate logs from every launch — apply the [start, end] window.
func collectWindowLines(tf *telemetryFile, launchID string, start, end time.Time) []timedLine {
	// Parse telemetry first_seen for a stream, returning zero on failure.
	parseTelemetryTS := func(s string) time.Time {
		if s == "" {
			return time.Time{}
		}
		if t, err := time.Parse(time.RFC3339, s); err == nil {
			return t
		}
		if t, err := time.Parse("2006-01-02T15:04:05.000Z", s); err == nil {
			return t
		}
		return time.Time{}
	}

	var all []timedLine
	for streamID, stream := range tf.ActiveStreams {
		var lines []timedLine
		switch {
		case isLaunchDedicatedStream(streamID, launchID):
			// Strategy 1: file is exclusive to this launch — read completely.
			lines = readStreamFull(stream.Path, false)

		case isSessionDayStream(streamID, stream, start, end):
			// Strategy 2: session-day stream whose lines lack per-line timestamps.
			// Read fully and backfill any zero-ts line with first_seen so the
			// unified timeline places them at the right moment instead of sorting
			// them to the front as ??:??:??.
			lines = readStreamFull(stream.Path, false)
			anchor := parseTelemetryTS(stream.FirstSeen)
			if !anchor.IsZero() {
				for i := range lines {
					if lines[i].ts.IsZero() {
						lines[i].ts = anchor
					}
				}
			}

		default:
			// Strategy 3: persistent stream — filter by time window.
			lines = readStreamWindow(stream.Path, start, end, false)
		}

		for _, tl := range lines {
			tl.stream = streamID
			all = append(all, tl)
		}
	}

	// Sort by timestamp, then by stream name for stability.
	// Lines with zero timestamp (true pre-header lines) sort to the front.
	sort.SliceStable(all, func(i, j int) bool {
		if all[i].ts.IsZero() && all[j].ts.IsZero() {
			return all[i].stream < all[j].stream
		}
		if all[i].ts.IsZero() {
			return true
		}
		if all[j].ts.IsZero() {
			return false
		}
		return all[i].ts.Before(all[j].ts)
	})
	return all
}

// invokeBrainCLI runs a Brain CLI command and returns parsed JSON output.
// Returns (outputFile, rawOutput, error).
//
// Brain CLI emite líneas INFO/DEBUG a stdout antes del JSON.
// Extrae la primera línea que empiece con '{'.
// La estructura de respuesta es: {"status":"success","data":{"output_file":"..."}}
func invokeBrainCLI(binDir string, args ...string) (string, string, error) {
	brainExe := filepath.Join(binDir, "brain", "brain.exe")
	if _, err := os.Stat(brainExe); err != nil {
		brainExeUnix := filepath.Join(binDir, "brain", "brain")
		if _, errUnix := os.Stat(brainExeUnix); errUnix == nil {
			brainExe = brainExeUnix  // path absoluto, no depende del PATH
		} else {
			brainExe = "brain"  
		}
	}

	allArgs := append([]string{"--json"}, args...)
	cmd := exec.Command(brainExe, allArgs...)
	out, err := cmd.Output()
	raw := string(out)
	if err != nil {
		return "", raw, fmt.Errorf("brain %s: %w\noutput: %s", strings.Join(args, " "), err, raw)
	}

	// Extraer línea JSON — brain CLI puede prefijar con líneas INFO/DEBUG
	jsonLine := ""
	for _, line := range strings.Split(raw, "\n") {
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "{") {
			jsonLine = line
			break
		}
	}
	if jsonLine == "" {
		return "", raw, fmt.Errorf("brain %s: no JSON en output: %s", strings.Join(args, " "), raw)
	}

	// Parsear {"status":"success","data":{"output_file":"..."}}
	var envelope struct {
		Status string                 `json:"status"`
		Data   map[string]interface{} `json:"data"`
	}
	if err := json.Unmarshal([]byte(jsonLine), &envelope); err != nil {
		return "", raw, fmt.Errorf("brain %s: JSON parse error: %w", strings.Join(args, " "), err)
	}
	if envelope.Status != "success" {
		return "", raw, fmt.Errorf("brain %s: status=%s", strings.Join(args, " "), envelope.Status)
	}
	if outFile, ok := envelope.Data["output_file"].(string); ok && outFile != "" {
		return outFile, raw, nil
	}
	return "", raw, fmt.Errorf("brain %s: output_file no encontrado en data", strings.Join(args, " "))
}

// readFileContents reads a file's content; returns placeholder on failure.
func readFileContents(path string) string {
	if path == "" {
		return "(not generated)"
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return fmt.Sprintf("(file not found: %s)", path)
	}
	return string(data)
}

// extractSummaryFacts scans the unified timeline for key facts.
type traceSummary struct {
	launchTime     string
	chromePID      string
	extensionOK    string
	cortexOK       string
	hostOK         string
	errorCount     int
	warningCount   int
	streamsActive  int
	totalLines     int
}

func extractSummaryFacts(lines []timedLine) traceSummary {
	s := traceSummary{
		launchTime:  "unknown",
		chromePID:   "unknown",
		extensionOK: "unknown",
		cortexOK:    "unknown",
		hostOK:      "unknown",
	}
	for _, l := range lines {
		s.totalLines++
		upper := strings.ToUpper(l.text)
		if strings.Contains(upper, "ERROR") {
			s.errorCount++
		} else if strings.Contains(upper, "WARNING") {
			s.warningCount++
		}
		// Chrome PID
		if s.chromePID == "unknown" && strings.Contains(l.text, "PID=") {
			pidIdx := strings.Index(l.text, "PID=")
			rest := l.text[pidIdx+4:]
			end := strings.IndexAny(rest, " \t\r\n")
			if end < 0 {
				end = len(rest)
			}
			s.chromePID = strings.TrimSpace(rest[:end])
		}
		// Extension
		if s.extensionOK == "unknown" {
			if strings.Contains(l.text, "extension loaded") || strings.Contains(l.text, "Extension loaded") {
				s.extensionOK = "true"
			} else if strings.Contains(upper, "EXTENSION") && strings.Contains(upper, "ERROR") {
				s.extensionOK = "false"
			}
		}
		// Cortex — detected from cortex stream
		if strings.Contains(l.stream, "cortex") {
			if s.cortexOK == "unknown" {
				s.cortexOK = "active"
			}
			if strings.Contains(upper, "ERROR") {
				s.cortexOK = "error"
			}
		}
		// Host — detected from host and nm_init_diag streams
		if strings.Contains(l.stream, "host") || strings.Contains(l.stream, "nm_init_diag") {
			if s.hostOK == "unknown" {
				s.hostOK = "active"
			}
			if strings.Contains(upper, "ERROR") {
				s.hostOK = "error"
			}
		}
	}
	// streams active
	seen := map[string]struct{}{}
	for _, l := range lines {
		seen[l.stream] = struct{}{}
	}
	s.streamsActive = len(seen)
	if len(lines) > 0 && !lines[0].ts.IsZero() {
		s.launchTime = lines[0].ts.Format("15:04:05")
	}
	return s
}

// streamSymbol returns a simple emoji prefix for known stream types.
func streamSymbol(stream, text string) string {
	upper := strings.ToUpper(text)
	if strings.Contains(upper, "ERROR") {
		return "❌"
	}
	if strings.Contains(upper, "WARNING") {
		return "⚠️ "
	}
	if strings.Contains(upper, "SUCCESS") || strings.Contains(text, "✅") {
		return "✅"
	}
	if strings.Contains(stream, "synapse") {
		return "�"
	}
	if strings.Contains(stream, "sentinel") {
		return "�️ "
	}
	if strings.Contains(stream, "cortex") {
		return "�"
	}
	if strings.Contains(stream, "host") || strings.Contains(stream, "nm_init_diag") {
		return "�️ "
	}
	if strings.Contains(stream, "telemetry") {
		return "�"
	}
	if strings.Contains(stream, "brain") {
		return "�"
	}
	return "  "
}

func runLaunchTrace(c *core.Core, launchID, profileID, outFilePath string, jsonOut bool, knownTS ...time.Time) error {
	tf, err := loadTelemetry(c.Paths.LogsDir)
	if err != nil {
		return err
	}

	// ── Step 1: Find launch timestamp ───────────────────────────────────────
	// Priority: knownTS passed by caller > search in synapse log > fallback now-5m
	var launchTS time.Time
	if len(knownTS) > 0 && !knownTS[0].IsZero() {
		launchTS = knownTS[0]
		fmt.Fprintf(os.Stderr, "[INFO] Usando timestamp del launch: %s\n", launchTS.Format(time.RFC3339))
	} else {
		synapseStream, hasSynapse := tf.ActiveStreams["nucleus_synapse"]
		if !hasSynapse {
			return fmt.Errorf("nucleus_synapse stream not found in telemetry.json")
		}
		var tsErr error
		launchTS, tsErr = findLaunchTimestamp(synapseStream.Path, launchID)
		if tsErr != nil {
			fmt.Fprintf(os.Stderr, "[WARNING] %v — using now-5m as fallback window start\n", tsErr)
			launchTS = time.Now().Add(-5 * time.Minute)
		}
	}

	// Ventana dinámica desde metadatos de telemetry.json.
	// Garantiza que ningún stream registrado quede cortado por un límite arbitrario.
	// Mínimo: launchTS-30s → launchTS+5m. Se extiende hasta max(last_update)+1m.
	windowStart, windowEnd := calculateWindowFromTelemetry(tf, launchTS)

	fmt.Fprintf(os.Stderr, "[INFO] Window: %s → %s\n",
		windowStart.Format(time.RFC3339), windowEnd.Format(time.RFC3339))

	// ── Step 2: Collect lines from all telemetry streams ────────────────────
	// Launch-dedicated streams (stream ID contains launchID) are read in full.
	// Persistent streams are filtered by the computed time window.
	allLines := collectWindowLines(tf, launchID, windowStart, windowEnd)

	// Collect inactive streams
	seenStreams := map[string]struct{}{}
	for _, l := range allLines {
		seenStreams[l.stream] = struct{}{}
	}
	var inactiveStreams []string
	for streamID, stream := range tf.ActiveStreams {
		if _, active := seenStreams[streamID]; !active {
			// Get last event time
			info, statErr := os.Stat(stream.Path)
			var lastEvent string
			if statErr == nil {
				diff := time.Since(info.ModTime()).Round(time.Minute)
				lastEvent = fmt.Sprintf("last event: %v ago", diff)
			} else {
				lastEvent = "file not found"
			}
			inactiveStreams = append(inactiveStreams, fmt.Sprintf("- %s (%s)", streamID, lastEvent))
		}
	}
	sort.Strings(inactiveStreams)

	// ── Step 3: Chrome engine log analysis ──────────────────────────────────────
	// Invoca brain CLI para generar los archivos _engine_*.log.
	// brain devuelve el output_file en su JSON — nucleus lo lee directamente
	// y registra el stream en telemetry usando el TelemetryManager en memoria,
	// evitando el race condition entre registerStreamCLI y autoSaveLoop.
	type chromeAnalysis struct {
		readLog    string
		networkLog string
		miningLog  string
		readErr    string
		networkErr string
		miningErr  string
	}
	var chrome chromeAnalysis

	if profileID != "" {
		fmt.Fprintln(os.Stderr, "[INFO] Invocando brain CLI para análisis Chrome...")
		tm := core.GetTelemetryManager(c.Paths.LogsDir, c.Paths.LogsDir)
		shortID := launchID
		if len(shortID) > 8 {
			shortID = shortID[:8]
		}

		// read-log → _engine_read.log
		readPath, _, readErr := invokeBrainCLI(c.Paths.BinDir,
			"chrome", "read-log", profileID, "--launch-id", launchID)
		if readErr != nil {
			chrome.readErr = readErr.Error()
			fmt.Fprintf(os.Stderr, "[WARN] brain chrome read-log: %v\n", readErr)
		} else {
			chrome.readLog = readFileContents(readPath)
			tm.RegisterStream(
				"chrome_engine_read_"+shortID,
				"� CHROME ENGINE AUDIT ("+shortID+")",
				2,
				[]string{"synapse"},
				"Chrome engine audit para launch "+launchID+" — detección de errores Chromium y bloqueos de seguridad",
				"brain",
				filepath.ToSlash(readPath),
			)
			fmt.Fprintf(os.Stderr, "[INFO] engine_read generado y registrado: %s\n", readPath)
		}

		// read-net-log → _engine_network.log
		netPath, _, netErr := invokeBrainCLI(c.Paths.BinDir,
			"chrome", "read-net-log", profileID, "--launch-id", launchID)
		if netErr != nil {
			chrome.networkErr = netErr.Error()
			fmt.Fprintf(os.Stderr, "[WARN] brain chrome read-net-log: %v\n", netErr)
		} else {
			chrome.networkLog = readFileContents(netPath)
			tm.RegisterStream(
				"chrome_network_"+shortID,
				"� CHROME NETWORK ("+shortID+")",
				2,
				[]string{"synapse"},
				"Chrome network log para launch "+launchID+" — requests URL y sesiones HTTP/2",
				"brain",
				filepath.ToSlash(netPath),
			)
			fmt.Fprintf(os.Stderr, "[INFO] engine_network generado y registrado: %s\n", netPath)
		}

		// mining-log → _engine_mining.log
		miningPath, _, miningErr := invokeBrainCLI(c.Paths.BinDir,
			"chrome", "mining-log", profileID, "--launch-id", launchID, "--keyword", "bloom")
		if miningErr != nil {
			chrome.miningErr = miningErr.Error()
			fmt.Fprintf(os.Stderr, "[WARN] brain chrome mining-log: %v\n", miningErr)
		} else {
			chrome.miningLog = readFileContents(miningPath)
			tm.RegisterStream(
				"chrome_engine_mining_"+shortID,
				"⛏️ CHROME ENGINE MINING ("+shortID+")",
				2,
				[]string{"synapse"},
				"Chrome mining log para launch "+launchID+" — bloom keyword extraction with context from engine debug output",
				"brain",
				filepath.ToSlash(miningPath),
			)
			fmt.Fprintf(os.Stderr, "[INFO] engine_mining generado y registrado: %s\n", miningPath)
		}
	} else {
		chrome.readErr = "profileID no provisto — análisis Chrome omitido"
		chrome.networkErr = chrome.readErr
		chrome.miningErr = chrome.readErr
	}

	// ── Step 4: Build digest file ─────────────────────────────────────────────
	traceDir := filepath.Join(c.Paths.LogsDir, "synapse_trace")
	if err := os.MkdirAll(traceDir, 0755); err != nil {
		return fmt.Errorf("cannot create synapse_trace dir: %w", err)
	}

	if outFilePath == "" {
		outFilePath = filepath.Join(traceDir, fmt.Sprintf("synapse_trace_%s.log", launchID))
	}

	sum := extractSummaryFacts(allLines)

	// Collect error lines for the ERRORES section
	var errorLines []timedLine
	for _, l := range allLines {
		upper := strings.ToUpper(l.text)
		if strings.Contains(upper, "ERROR") || strings.Contains(upper, "WARNING") {
			errorLines = append(errorLines, l)
		}
	}

	f, err := os.Create(outFilePath)
	if err != nil {
		return fmt.Errorf("cannot create trace file: %w", err)
	}
	defer f.Close()
	w := bufio.NewWriter(f)

	sep := strings.Repeat("=", 80)
	dash := strings.Repeat("-", 80)

	fmt.Fprintf(w, "%s\n", sep)
	fmt.Fprintf(w, "SYNAPSE TRACE — launch_id: %s\n", launchID)
	fmt.Fprintf(w, "Generado: %s\n", time.Now().UTC().Format(time.RFC3339))
	fmt.Fprintf(w, "Ventana: %s → %s\n", windowStart.Format(time.RFC3339), windowEnd.Format(time.RFC3339))
	if profileID != "" {
		fmt.Fprintf(w, "Profile:  %s\n", profileID)
	}
	fmt.Fprintf(w, "%s\n\n", sep)

	// RESUMEN EJECUTIVO
	fmt.Fprintf(w, "[RESUMEN EJECUTIVO]\n")
	fmt.Fprintf(w, "- Launch iniciado:   %s\n", sum.launchTime)
	fmt.Fprintf(w, "- Chrome PID:        %s\n", sum.chromePID)
	fmt.Fprintf(w, "- Extension loaded:  %s\n", sum.extensionOK)
	fmt.Fprintf(w, "- Cortex:            %s\n", sum.cortexOK)
	fmt.Fprintf(w, "- Host:              %s\n", sum.hostOK)
	fmt.Fprintf(w, "- Errores detectados:  %d\n", sum.errorCount)
	fmt.Fprintf(w, "- Warnings detectados: %d\n", sum.warningCount)
	fmt.Fprintf(w, "- Streams analizados:  %d\n", sum.streamsActive)
	fmt.Fprintf(w, "- Líneas totales:      %d\n", sum.totalLines)
	fmt.Fprintf(w, "\n%s\n", sep)

	// LÍNEA DE TIEMPO UNIFICADA
	fmt.Fprintf(w, "\n[LÍNEA DE TIEMPO UNIFICADA]\n\n")
	for _, l := range allLines {
		tsStr := "??:??:??"
		if !l.ts.IsZero() {
			tsStr = l.ts.Format("15:04:05")
		}
		sym := streamSymbol(l.stream, l.text)
		// Pad stream name for alignment
		paddedStream := fmt.Sprintf("%-28s", "["+l.stream+"]")
		fmt.Fprintf(w, "%s %s %s %s\n", tsStr, paddedStream, sym, l.text)
	}
	fmt.Fprintf(w, "\n%s\n", sep)

	// ERRORES DETECTADOS
	fmt.Fprintf(w, "\n[ERRORES DETECTADOS]\n\n")
	if len(errorLines) == 0 {
		fmt.Fprintf(w, "(ningún error o warning encontrado en la ventana)\n")
	} else {
		for _, l := range errorLines {
			tsStr := "??:??:??"
			if !l.ts.IsZero() {
				tsStr = l.ts.Format("15:04:05")
			}
			fmt.Fprintf(w, "%s [%s] %s\n", tsStr, l.stream, l.text)
		}
	}
	fmt.Fprintf(w, "\n%s\n", sep)

	// ANÁLISIS CHROME
	fmt.Fprintf(w, "\n[ANÁLISIS CHROME — read-log]\n\n")
	if chrome.readErr != "" {
		fmt.Fprintf(w, "ERROR: %s\n", chrome.readErr)
	} else if chrome.readLog != "" {
		fmt.Fprintf(w, "%s\n", chrome.readLog)
	} else {
		fmt.Fprintf(w, "(no se proveyó --profile, análisis Chrome omitido)\n")
	}
	fmt.Fprintf(w, "\n%s\n", dash)

	fmt.Fprintf(w, "\n[ANÁLISIS CHROME — network]\n\n")
	if chrome.networkErr != "" {
		fmt.Fprintf(w, "ERROR: %s\n", chrome.networkErr)
	} else if chrome.networkLog != "" {
		fmt.Fprintf(w, "%s\n", chrome.networkLog)
	} else {
		fmt.Fprintf(w, "(no se proveyó --profile, análisis de red omitido)\n")
	}
	fmt.Fprintf(w, "\n%s\n", dash)

	fmt.Fprintf(w, "\n[ANÁLISIS CHROME — mining bloom]\n\n")
	if chrome.miningErr != "" {
		fmt.Fprintf(w, "ERROR: %s\n", chrome.miningErr)
	} else if chrome.miningLog != "" {
		fmt.Fprintf(w, "%s\n", chrome.miningLog)
	} else {
		fmt.Fprintf(w, "(no se proveyó --profile, mining log omitido)\n")
	}
	fmt.Fprintf(w, "\n%s\n", sep)

	// ── CORTEX EXTENSION LOG ──────────────────────────────────────────────────
	fmt.Fprintf(w, "\n[CORTEX EXTENSION — bloom-cortex]\n\n")
	cortexWritten := false
	for streamID, stream := range tf.ActiveStreams {
		if !strings.Contains(streamID, "cortex") {
			continue
		}
		// cortex streams are always launch-dedicated (e.g. cortex_005_cbc25063_090120)
		// so we read them in full — no time-window filtering needed.
		var lines []timedLine
		if isLaunchDedicatedStream(streamID, launchID) {
			lines = readStreamFull(stream.Path, false)
		} else {
			lines = readStreamWindow(stream.Path, windowStart, windowEnd, false)
		}
		if len(lines) == 0 {
			fmt.Fprintf(w, "(%s: sin actividad)\n", streamID)
		} else {
			fmt.Fprintf(w, "--- %s (%s) ---\n", stream.Label, streamID)
			for _, l := range lines {
				if strings.TrimSpace(l.text) == "" {
					continue
				}
				tsStr := "??:??:??"
				if !l.ts.IsZero() {
					tsStr = l.ts.Format("15:04:05")
				}
				fmt.Fprintf(w, "%s %s\n", tsStr, l.text)
			}
			fmt.Fprintln(w)
		}
		cortexWritten = true
	}
	if !cortexWritten {
		fmt.Fprintf(w, "(stream cortex no encontrado en telemetry.json para este launch)\n")
	}
	fmt.Fprintf(w, "\n%s\n", dash)

	// ── HOST LOG ──────────────────────────────────────────────────────────────
	fmt.Fprintf(w, "\n[HOST — bloom-host]\n\n")
	hostWritten := false
	for streamID, stream := range tf.ActiveStreams {
		if !strings.Contains(streamID, "host") && !strings.Contains(streamID, "nm_init_diag") {
			continue
		}
		// host streams are always launch-dedicated (e.g. host_005_cbc25063_090120)
		// so we read them in full — no time-window filtering needed.
		var lines []timedLine
		if isLaunchDedicatedStream(streamID, launchID) {
			lines = readStreamFull(stream.Path, false)
		} else {
			lines = readStreamWindow(stream.Path, windowStart, windowEnd, false)
		}
		if len(lines) == 0 {
			fmt.Fprintf(w, "(%s: sin actividad)\n", streamID)
		} else {
			fmt.Fprintf(w, "--- %s (%s) ---\n", stream.Label, streamID)
			for _, l := range lines {
				if strings.TrimSpace(l.text) == "" {
					continue
				}
				tsStr := "??:??:??"
				if !l.ts.IsZero() {
					tsStr = l.ts.Format("15:04:05")
				}
				fmt.Fprintf(w, "%s %s\n", tsStr, l.text)
			}
			fmt.Fprintln(w)
		}
		hostWritten = true
	}
	if !hostWritten {
		fmt.Fprintf(w, "(stream host no encontrado en telemetry.json para este launch)\n")
	}
	fmt.Fprintf(w, "\n%s\n", dash)

	// ── NUCLEUS TELEMETRY LOG ─────────────────────────────────────────────────
	fmt.Fprintf(w, "\n[NUCLEUS TELEMETRY — telemetry.json events]\n\n")
	telemetryWritten := false
	for streamID, stream := range tf.ActiveStreams {
		if streamID != "nucleus_telemetry" {
			continue
		}
		lines := readStreamWindow(stream.Path, windowStart, windowEnd, false)
		if len(lines) == 0 {
			fmt.Fprintf(w, "(nucleus_telemetry: sin actividad en ventana)\n")
		} else {
			for _, l := range lines {
				if strings.TrimSpace(l.text) == "" {
					continue
				}
				tsStr := "??:??:??"
				if !l.ts.IsZero() {
					tsStr = l.ts.Format("15:04:05")
				}
				fmt.Fprintf(w, "%s %s\n", tsStr, l.text)
			}
		}
		telemetryWritten = true
		break
	}
	if !telemetryWritten {
		fmt.Fprintf(w, "(stream nucleus_telemetry no encontrado en telemetry.json)\n")
	}
	fmt.Fprintf(w, "\n%s\n", sep)

	// STREAMS SIN ACTIVIDAD
	fmt.Fprintf(w, "\n[STREAMS SIN ACTIVIDAD EN VENTANA]\n\n")
	if len(inactiveStreams) == 0 {
		fmt.Fprintf(w, "(todos los streams tuvieron actividad en la ventana)\n")
	} else {
		for _, s := range inactiveStreams {
			fmt.Fprintf(w, "%s\n", s)
		}
	}
	fmt.Fprintf(w, "\n%s\n", sep)

	if err := w.Flush(); err != nil {
		return fmt.Errorf("flushing trace file: %w", err)
	}

	// ── Step 5: Register in telemetry ────────────────────────────────────────
	tm := core.GetTelemetryManager(c.Paths.LogsDir, c.Paths.LogsDir)
	tm.RegisterStream(
		fmt.Sprintf("synapse_trace_%s", launchID),
		fmt.Sprintf("� SYNAPSE TRACE (%s)", launchID),
		2,
		[]string{"nucleus", "synapse"},
		fmt.Sprintf("Synapse trace log — correlación temporal de todos los streams activos para launch %s (profile: %s)", launchID, profileID),
		"nucleus",
		filepath.ToSlash(outFilePath),
	)

	// ── Output ────────────────────────────────────────────────────────────────
	if jsonOut {
		outputJSON(map[string]interface{}{
			"success":      true,
			"mode":         "launch",
			"launch_id":    launchID,
			"profile_id":   profileID,
			"output_file":  filepath.ToSlash(outFilePath),
			"window_start": windowStart.Format(time.RFC3339),
			"window_end":   windowEnd.Format(time.RFC3339),
			"total_lines":  sum.totalLines,
			"errors":       sum.errorCount,
			"warnings":     sum.warningCount,
		})
		return nil
	}

	fmt.Printf("\n✅ Synapse trace generado: %s\n", outFilePath)
	fmt.Printf("   Ventana: %s → %s\n", windowStart.Format("15:04:05"), windowEnd.Format("15:04:05"))
	fmt.Printf("   Líneas:  %d | Errores: %d | Warnings: %d\n\n",
		sum.totalLines, sum.errorCount, sum.warningCount)
	return nil
}

// ═════════════════════════════════════════════════════════════════════════════
// MODE 3: SUMMARY DASHBOARD
// ═════════════════════════════════════════════════════════════════════════════

type streamStats struct {
	streamID    string
	lastSeen    time.Duration
	errorCount  int
	warnCount   int
	fileExists  bool
}

func runSummary(c *core.Core, since string, jsonOut bool) error {
	tf, err := loadTelemetry(c.Paths.LogsDir)
	if err != nil {
		return err
	}

	var dur time.Duration = 10 * time.Minute // default
	if since != "" {
		dur, err = parseSinceDuration(since)
		if err != nil {
			return err
		}
	}

	cutoff := time.Now().Add(-dur)

	var stats []streamStats
	for streamID, stream := range tf.ActiveStreams {
		s := streamStats{streamID: streamID}

		info, statErr := os.Stat(stream.Path)
		if statErr != nil {
			s.fileExists = false
			stats = append(stats, s)
			continue
		}
		s.fileExists = true
		s.lastSeen = time.Since(info.ModTime()).Round(time.Second)

		// Count errors/warnings in the since window
		f, openErr := os.Open(stream.Path)
		if openErr == nil {
			scanner := bufio.NewScanner(f)
			scanner.Buffer(make([]byte, 1024*1024), 1024*1024)
			for scanner.Scan() {
				line := scanner.Text()
				ts := parseLineTimestamp(line)
				if !ts.IsZero() && ts.Before(cutoff) {
					continue
				}
				upper := strings.ToUpper(line)
				if strings.Contains(upper, "ERROR") {
					s.errorCount++
				} else if strings.Contains(upper, "WARNING") {
					s.warnCount++
				}
			}
			f.Close()
		}
		stats = append(stats, s)
	}

	// Sort by stream ID for stable output
	sort.Slice(stats, func(i, j int) bool {
		return stats[i].streamID < stats[j].streamID
	})

	if jsonOut {
		type jsonStream struct {
			StreamID    string `json:"stream_id"`
			LastSeenAgo string `json:"last_seen_ago"`
			Errors      int    `json:"errors"`
			Warnings    int    `json:"warnings"`
			FileExists  bool   `json:"file_exists"`
		}
		var out []jsonStream
		for _, s := range stats {
			out = append(out, jsonStream{
				StreamID:    s.streamID,
				LastSeenAgo: s.lastSeen.String(),
				Errors:      s.errorCount,
				Warnings:    s.warnCount,
				FileExists:  s.fileExists,
			})
		}
		outputJSON(map[string]interface{}{
			"success":   true,
			"mode":      "summary",
			"since":     since,
			"streams":   out,
			"timestamp": time.Now().UTC().Format(time.RFC3339),
		})
		return nil
	}

	// ── Terminal table ────────────────────────────────────────────────────────
	const reset = "\033[0m"
	const red = "\033[31m"
	const yellow = "\033[33m"

	// Header
	fmt.Printf("\n%-32s  %-18s  %s (%s)  %s (%s)\n",
		"stream", "última actividad",
		"errores", dur.String(), "warnings", dur.String())
	fmt.Println(strings.Repeat("-", 80))

	for _, s := range stats {
		if !s.fileExists {
			fmt.Printf("%-32s  %-18s  -               -\n", s.streamID, "(archivo no existe)")
			continue
		}

		lastStr := formatDurationAgo(s.lastSeen)
		errStr := strconv.Itoa(s.errorCount)
		warnStr := strconv.Itoa(s.warnCount)

		// Colorize if errors present
		errColor := ""
		errReset := ""
		if s.errorCount > 0 {
			errColor = red
			errReset = reset
			errStr = errStr + "  ←"
		}
		warnColor := ""
		warnReset := ""
		if s.warnCount > 0 {
			warnColor = yellow
			warnReset = reset
		}

		fmt.Printf("%-32s  %-18s  %s%-14s%s%s%-14s%s\n",
			s.streamID, lastStr,
			errColor, errStr, errReset,
			warnColor, warnStr, warnReset,
		)
	}
	fmt.Println()
	return nil
}

func formatDurationAgo(d time.Duration) string {
	if d < time.Minute {
		return fmt.Sprintf("hace %ds", int(d.Seconds()))
	}
	if d < time.Hour {
		return fmt.Sprintf("hace %dmin", int(d.Minutes()))
	}
	return fmt.Sprintf("hace %.1fh", d.Hours())
}