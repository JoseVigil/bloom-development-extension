// File: internal/orchestration/temporal/workflows/profile_lifecycle.go
// v1.1.0 — Paso 1 github_auth
// Cambios:
//   - Agrega tipo OnboardingState con CurrentStep, CompletedSteps, Artifacts, StartedAt, LastStepAt
//   - Agrega campo Onboarding OnboardingState a ProfileStatus (via types package — ver nota abajo)
//   - Agrega QueryHandler para queries.QueryOnboardingState
//   - Agrega case signals.EventOnboardingStepComplete en el switch de BRAIN_EVENT
//   - SentinelLaunchInput.OverrideStep usa state.Onboarding.CurrentStep si no está vacío
//
// NOTA sobre OnboardingState: idealmente vive en nucleus/internal/orchestration/types.
// Se declara aquí para este paso — mover al paquete types en el siguiente refactor.
package workflows

import (
	"fmt"
	"time"

	"go.temporal.io/sdk/temporal"
	"go.temporal.io/sdk/workflow"

	"nucleus/internal/mandates"
	"nucleus/internal/orchestration/queries"
	"nucleus/internal/orchestration/signals"
	"nucleus/internal/orchestration/types"
)

// OnboardingState mantiene el estado del onboarding del perfil.
// Persiste en el workflow de Temporal — si Chrome se cierra a mitad del
// onboarding, el siguiente launch lee CurrentStep y resume desde ahí.
type OnboardingState struct {
	// CurrentStep es el step activo actualmente (ej: "github_auth", "vault_init")
	CurrentStep string `json:"current_step"`

	// CompletedSteps es la lista ordenada de steps ya completados
	CompletedSteps []string `json:"completed_steps"`

	// Artifacts mapea el produce de cada step a true cuando el step completó.
	// Keys: "github_token", "nucleus_path", "vault_initialized", "google_account", etc.
	Artifacts map[string]bool `json:"artifacts"`

	// StartedAt es el timestamp del primer step iniciado
	StartedAt time.Time `json:"started_at"`

	// LastStepAt es el timestamp del último step completado
	LastStepAt time.Time `json:"last_step_at"`
}

// stepProducesArtifact mapea cada step ID al artifact que produce.
// Sincronizado con config/onboarding_steps.json.
var stepProducesArtifact = map[string]string{
	"github_auth":      "github_token",
	"nucleus_create":   "nucleus_path",
	"vault_init":       "vault_initialized",
	"google_auth":      "google_account",
	"ai_provider_setup": "ai_provider_key",
	"project_create":   "project_mandate",
}


// maxLaunchesBeforeReset define cuántos launches se acumulan antes de hacer ContinueAsNew.
// Temporal tiene un límite de ~50k eventos por run. Cada launch genera aprox. 400-600 eventos
// (activity scheduling, heartbeats, signals, timers). Con 75 launches tenemos margen holgado.
const maxLaunchesBeforeReset = 75

// ProfileLifecycleWorkflow es el workflow principal que orquesta el ciclo de vida de un perfil.
// Este workflow es de larga duración y representa el "actor persistente" del perfil.
// Un perfil puede ser lanzado y detenido cientos de veces — el workflow NUNCA termina
// por un shutdown normal. Solo termina si se recibe una señal de eliminación definitiva.
//
// ContinueAsNew: cada maxLaunchesBeforeReset launches, el workflow se reinicia con un historial
// limpio preservando el estado actual en ProfileLifecycleInput.LaunchCount.
func ProfileLifecycleWorkflow(ctx workflow.Context, input types.ProfileLifecycleInput) error {
	logger := workflow.GetLogger(ctx)
	logger.Info("ProfileLifecycleWorkflow started",
		"profile_id", input.ProfileID,
		"launch_count_offset", input.LaunchCount)

	// Estado mutable del workflow
	state := types.ProfileStatus{
		ProfileID:       input.ProfileID,
		State:           types.StateSeeded,
		LastUpdate:      workflow.Now(ctx),
		SentinelRunning: false,
	}

	// Estado de onboarding — se inicializa vacío y se puebla conforme
	// llegan eventos ONBOARDING_STEP_COMPLETE desde el Brain.
	// Se preserva en ContinueAsNew via input.OnboardingState si se agrega ese campo.
	onboarding := OnboardingState{
		Artifacts: make(map[string]bool),
	}

	// Detalles completos de Sentinel cuando esté lanzado
	var sentinelDetails *types.SentinelLaunchResult

	// launchCount acumula el total de launches en este run.
	// Se inicializa desde input.LaunchCount para que el conteo sea correcto
	// tras un ContinueAsNew (el campo preserva el offset del run anterior).
	launchCount := input.LaunchCount

	// Channels para signals
	launchSignalChan := workflow.GetSignalChannel(ctx, signals.SignalLaunch)
	shutdownChan := workflow.GetSignalChannel(ctx, signals.SignalShutdown)
	heartbeatChan := workflow.GetSignalChannel(ctx, signals.SignalHeartbeat)
	brainEventChan := workflow.GetSignalChannel(ctx, signals.SignalBrainEvent)

	// Registrar query para estado básico
	if err := workflow.SetQueryHandler(ctx, queries.QueryStatus, func() (types.ProfileStatus, error) {
		return state, nil
	}); err != nil {
		return fmt.Errorf("failed to register status query: %w", err)
	}

	// Registrar query para detalles completos de Sentinel
	if err := workflow.SetQueryHandler(ctx, queries.QuerySentinelDetails, func() (*types.SentinelLaunchResult, error) {
		if sentinelDetails == nil {
			return nil, fmt.Errorf("sentinel not launched yet")
		}
		return sentinelDetails, nil
	}); err != nil {
		return fmt.Errorf("failed to register sentinel-details query: %w", err)
	}

	// Registrar query para estado de onboarding — permite leer CurrentStep, CompletedSteps y Artifacts
	if err := workflow.SetQueryHandler(ctx, queries.QueryOnboardingState, func() (OnboardingState, error) {
		return onboarding, nil
	}); err != nil {
		return fmt.Errorf("failed to register onboarding-state query: %w", err)
	}

	// Activity options para LaunchSentinel con retry policy conservadora.
	// InitialInterval de 15s evita que los retries rápidos dejen recursos
	// parcialmente ocupados (puertos, locks, procesos zombie) entre intentos.
	// NonRetryableErrorTypes evita reintentos en errores estructurales que
	// no se van a resolver solos independientemente de cuántas veces se reintente.
	activityOptions := workflow.ActivityOptions{
		StartToCloseTimeout: 5 * time.Minute,
		HeartbeatTimeout:    30 * time.Second,
		RetryPolicy: &temporal.RetryPolicy{
			MaximumAttempts:    3,
			InitialInterval:    15 * time.Second,
			BackoffCoefficient: 2.0,
			MaximumInterval:    2 * time.Minute,
			NonRetryableErrorTypes: []string{
				"ProfileNotFoundError",
				"InvalidConfigError",
			},
		},
	}
	ctx = workflow.WithActivityOptions(ctx, activityOptions)

	// Variables para tracking de sesión actual
	var currentCommandID string
	var chromePID int
	var lastHeartbeat time.Time

	// cancelHeartbeatTimer permite cancelar el timer del ciclo anterior
	// antes de crear uno nuevo, evitando la acumulación de timers.
	var cancelHeartbeatTimer func()

	// Loop principal — permanece activo mientras el perfil existe.
	// Un perfil puede ser lanzado y detenido N veces sin que el workflow termine.
	for {
		selector := workflow.NewSelector(ctx)

		// Signal: LAUNCH — Lanzar Sentinel para este perfil
		selector.AddReceive(launchSignalChan, func(c workflow.ReceiveChannel, more bool) {
			var launchSignal types.LaunchSignal
			c.Receive(ctx, &launchSignal)

			logger.Info("Received LAUNCH signal",
				"profile_id", input.ProfileID,
				"mode", launchSignal.Mode)

			// Si SentinelRunning=true, puede ser un estado legítimo (doble launch)
			// o un estado huérfano (shutdown perdido durante restart del worker).
			// En lugar de ignorar, forzar reset y continuar — el launch va a
			// fallar igual si Sentinel realmente sigue corriendo (puerto ocupado,
			// proceso vivo), pero evita bloqueos permanentes por señales perdidas.
			if state.SentinelRunning {
				logger.Warn("SentinelRunning=true on LAUNCH — forcing reset (possible lost shutdown signal)",
					"profile_id", input.ProfileID,
					"chrome_pid", chromePID)
				state.SentinelRunning = false
				state.State = types.StateSeeded
				chromePID = 0
				currentCommandID = ""
				sentinelDetails = nil
			}

			// FIX: Si el estado es StateFailed (de un intento anterior fallido),
			// resetear antes de intentar un nuevo launch. Sin este reset, el workflow
			// queda bloqueado en StateFailed tras 3 intentos fallidos de la activity
			// y no acepta nuevos lanzamientos hasta un restart manual del workflow.
			if state.State == types.StateFailed {
				logger.Info("Resetting from StateFailed to attempt new launch",
					"profile_id", input.ProfileID)
				state.ErrorMessage = ""
				sentinelDetails = nil
			}

			// Transición a LAUNCHING
			state.State = types.StateLaunching
			state.LastUpdate = workflow.Now(ctx)

			// Generar CommandID único para esta sesión
			currentCommandID = fmt.Sprintf("launch_%s_%d", input.ProfileID, workflow.Now(ctx).UnixNano())

			launchInput := types.SentinelLaunchInput{
				ProfileID:         input.ProfileID,
				CommandID:         currentCommandID,
				Environment:       input.Environment,
				Mode:              launchSignal.Mode,
				ConfigOverride:    launchSignal.ConfigOverride,
				OverrideAlias:     launchSignal.OverrideAlias,
				OverrideEmail:     launchSignal.OverrideEmail,
				OverrideExtension: launchSignal.OverrideExtension,
				OverrideHeartbeat: launchSignal.OverrideHeartbeat,
				OverrideRegister:  launchSignal.OverrideRegister,
				OverrideRole:      launchSignal.OverrideRole,
				OverrideService:   launchSignal.OverrideService,
				// Resume automático: si el onboarding tiene un step activo (ej: usuario cerró
				// Chrome a mitad del onboarding), se lo pasamos como OverrideStep para que
				// Sentinel abra directamente la pantalla correcta sin volver al inicio.
				// El signal explícito de launch tiene prioridad si viene con su propio step.
				OverrideStep: func() string {
					if launchSignal.OverrideStep != "" {
						return launchSignal.OverrideStep
					}
					return onboarding.CurrentStep
				}(),
				Save:        launchSignal.Save,
				AddAccounts: launchSignal.AddAccounts,
			}

			var launchResult types.SentinelLaunchResult
			err := workflow.ExecuteActivity(ctx, "sentinel.LaunchSentinel", launchInput).Get(ctx, &launchResult)

			if err != nil {
				logger.Error("LaunchSentinel activity failed", "error", err)
				state.State = types.StateFailed
				state.ErrorMessage = err.Error()
				state.LastUpdate = workflow.Now(ctx)
				sentinelDetails = &types.SentinelLaunchResult{
					Success: false,
					Error:   err.Error(),
				}
				return
			}

			sentinelDetails = &launchResult

			if launchResult.Success {
				state.State = types.StateRunning
				state.SentinelRunning = true
				state.ErrorMessage = ""
				chromePID = launchResult.ChromePID
				lastHeartbeat = workflow.Now(ctx)

				// Incrementar contador de launches. Cuando alcance maxLaunchesBeforeReset
				// el loop principal triggerea ContinueAsNew para limpiar el historial.
				launchCount++

				logger.Info("Sentinel launched successfully",
					"chrome_pid", launchResult.ChromePID,
					"debug_port", launchResult.DebugPort,
					"extension_loaded", launchResult.ExtensionLoaded,
					"launch_count", launchCount)

				// ── POST-LAUNCH HOOKS ─────────────────────────────────────────────
				// Best-effort: los hooks no bloquean el workflow si fallan.
				// Se usa un ActivityOptions propio con retry deshabilitado.
				hookCtx := workflow.WithActivityOptions(ctx, workflow.ActivityOptions{
					StartToCloseTimeout: 2 * time.Minute,
					RetryPolicy: &temporal.RetryPolicy{
						MaximumAttempts: 1,
					},
				})
				hctx := mandates.NewHookContext(launchResult.LaunchID, input.ProfileID)
				var hooksResult mandates.HooksRunResult
				if err := workflow.ExecuteActivity(hookCtx, mandates.RunPostLaunchHooksActivity, hctx).Get(ctx, &hooksResult); err != nil {
					logger.Warn("post_launch hooks activity failed (non-fatal)", "error", err)
				} else {
					logger.Info("post_launch hooks completed",
						"total", hooksResult.Total,
						"failed", hooksResult.Failed,
						"launch_id", launchResult.LaunchID)
				}
				// ─────────────────────────────────────────────────────────────────
			} else {
				state.State = types.StateFailed
				state.ErrorMessage = launchResult.Error
				logger.Error("Sentinel launch failed", "error", launchResult.Error)
			}

			state.LastUpdate = workflow.Now(ctx)
		})

		// Signal: SHUTDOWN — Detener Sentinel y volver a SEEDED para próximo launch.
		// CRÍTICO: NO termina el workflow. El perfil puede relanzarse N veces.
		// El loop continúa esperando el próximo LAUNCH signal.
		selector.AddReceive(shutdownChan, func(c workflow.ReceiveChannel, more bool) {
			var shutdownSignal interface{}
			c.Receive(ctx, &shutdownSignal)

			logger.Info("Received SHUTDOWN signal", "profile_id", input.ProfileID)

			state.State = types.StateShutdown
			state.LastUpdate = workflow.Now(ctx)

			// Detener Sentinel si está corriendo
			if state.SentinelRunning && chromePID > 0 {
				stopInput := types.SentinelStopInput{
					ProfileID: input.ProfileID,
					CommandID: currentCommandID,
					ProcessID: chromePID,
				}

				var stopResult types.SentinelStopResult
				err := workflow.ExecuteActivity(ctx, "sentinel.StopSentinel", stopInput).Get(ctx, &stopResult)

				if err != nil {
					logger.Error("Failed to stop Sentinel", "error", err)
				} else if stopResult.Success {
					logger.Info("Sentinel stopped successfully")
				} else {
					logger.Error("Sentinel stop failed", "error", stopResult.Error)
				}
			}

			// Cancelar el timer de heartbeat si hay uno pendiente
			if cancelHeartbeatTimer != nil {
				cancelHeartbeatTimer()
				cancelHeartbeatTimer = nil
			}

			// Resetear sesión — listo para próximo LAUNCH
			state.State = types.StateSeeded
			state.SentinelRunning = false
			state.ErrorMessage = ""
			chromePID = 0
			currentCommandID = ""
			sentinelDetails = nil
			state.LastUpdate = workflow.Now(ctx)

			logger.Info("Profile stopped and ready for relaunch",
				"profile_id", input.ProfileID,
				"launch_count", launchCount)
			// NO hay return — el loop continúa esperando el próximo LAUNCH signal
		})

		// Signal: HEARTBEAT — Confirmación de que Sentinel sigue vivo
		selector.AddReceive(heartbeatChan, func(c workflow.ReceiveChannel, more bool) {
			var heartbeat types.HeartbeatSignal
			c.Receive(ctx, &heartbeat)

			// Cancelar el timer pendiente del ciclo anterior antes de renovar
			if cancelHeartbeatTimer != nil {
				cancelHeartbeatTimer()
				cancelHeartbeatTimer = nil
			}

			lastHeartbeat = workflow.Now(ctx)
			logger.Debug("Received heartbeat", "profile_id", input.ProfileID)
		})

		// Signal: BRAIN_EVENT — Eventos del Brain
		selector.AddReceive(brainEventChan, func(c workflow.ReceiveChannel, more bool) {
			var event types.BrainEvent
			c.Receive(ctx, &event)

			logger.Info("Received brain event",
				"type", event.Type,
				"profile_id", event.ProfileID)

			state.LastUpdate = workflow.Now(ctx)

			switch event.Type {
			case signals.EventOnboardingStarted:
				if state.State == types.StateSeeded {
					state.State = types.StateOnboarding
					logger.Info("Profile entering onboarding state")
				}

			case signals.EventOnboardingComplete:
				if state.State == types.StateOnboarding {
					state.State = types.StateReady
					logger.Info("Profile onboarding completed, now READY")
				}

			case signals.EventOnboardingFailed:
				state.State = types.StateFailed
				state.ErrorMessage = event.Error
				logger.Error("Profile onboarding failed", "error", event.Error)

			case signals.EventExtensionError:
				// Error de extensión no fatal — perfil pasa a IDLE para permitir relaunch
				if state.State == types.StateRunning {
					state.State = types.StateIdle
					state.ErrorMessage = event.Error
					logger.Warn("Profile set to IDLE due to extension error", "error", event.Error)
				}

			case signals.EventHeartbeatFailed:
				// Lanzar recovery directamente sin pasar por DEGRADED
				if state.State == types.StateRunning {
					logger.Warn("Heartbeat failed — launching recovery workflow")

					recoveryInput := types.RecoveryFlowInput{
						ProfileID:    input.ProfileID,
						FailureType:  "HEARTBEAT_FAILED",
						ErrorMessage: event.Error,
					}

					childWorkflowOptions := workflow.ChildWorkflowOptions{
						WorkflowID: fmt.Sprintf("recovery_%s_%d", input.ProfileID, workflow.Now(ctx).UnixNano()),
					}
					childCtx := workflow.WithChildOptions(ctx, childWorkflowOptions)

					var recoveryResult types.RecoveryFlowResult
					err := workflow.ExecuteChildWorkflow(childCtx, RecoveryFlowWorkflow, recoveryInput).Get(ctx, &recoveryResult)

					if err != nil {
						logger.Error("Recovery workflow failed", "error", err)
						state.State = types.StateFailed
						state.ErrorMessage = fmt.Sprintf("recovery failed: %v", err)
					} else if recoveryResult.Success {
						state.State = recoveryResult.NewState
						state.ErrorMessage = ""
						logger.Info("Recovery completed successfully", "new_state", state.State)
					} else {
						state.State = types.StateIdle
						state.ErrorMessage = "recovery unsuccessful — profile idle"
						logger.Warn("Recovery unsuccessful, profile set to IDLE")
					}
				}

			case signals.EventServiceRecoveryStarted:
				state.State = types.StateRecovering
				logger.Info("Service recovery started")

			case signals.EventServiceRecoveryComplete:
				state.State = types.StateRunning
				state.ErrorMessage = ""
				logger.Info("Service recovery completed")

			case signals.EventOnboardingStepComplete:
				// Paso 1 github_auth — actualiza el estado de onboarding cuando
				// ServerManager emite ONBOARDING_STEP_COMPLETE tras recibir
				// GITHUB_TOKEN_STORED (u otros steps futuros) desde la extensión.
				//
				// event.Data es map[string]interface{} con campos:
				//   "step"             : string — ID del step completado (ej: "github_auth")
				//   "token_fingerprint": string — solo presente para github_auth
				//   "profile_id"       : string — para validación

				completedStep, _ := event.Data["step"].(string)
				if completedStep == "" {
					logger.Warn("EventOnboardingStepComplete received with empty step — ignoring")
					break
				}

				// Inicializar mapa de artifacts si todavía es nil
				if onboarding.Artifacts == nil {
					onboarding.Artifacts = make(map[string]bool)
				}

				// Registrar el step previo como completado en la lista
				if onboarding.CurrentStep != "" && onboarding.CurrentStep != completedStep {
					onboarding.CompletedSteps = append(onboarding.CompletedSteps, onboarding.CurrentStep)
				}

				// Marcar el artifact del step como producido
				if artifact, ok := stepProducesArtifact[completedStep]; ok {
					onboarding.Artifacts[artifact] = true
				}

				// El step completado pasa a ser el "paso recién terminado"
				// CurrentStep se actualizará al siguiente step cuando Ignition lo navegue
				onboarding.CompletedSteps = append(onboarding.CompletedSteps, completedStep)
				onboarding.CurrentStep = completedStep
				onboarding.LastStepAt = workflow.Now(ctx)
				if onboarding.StartedAt.IsZero() {
					onboarding.StartedAt = workflow.Now(ctx)
				}

				logger.Info("Onboarding step complete recorded",
					"step", completedStep,
					"completed_count", len(onboarding.CompletedSteps),
					"artifacts", onboarding.Artifacts,
				)
			}
		})

		// Timer: Verificación periódica de heartbeat cuando Sentinel está corriendo.
		// CRÍTICO: cancelar el timer del ciclo anterior antes de crear uno nuevo.
		// Sin esto, cada iteración del loop acumula un timer pendiente y eventualmente
		// uno dispara aunque los heartbeats lleguen correctamente.
		if state.SentinelRunning && state.State == types.StateRunning {
			if cancelHeartbeatTimer != nil {
				cancelHeartbeatTimer()
			}
			timerCtx, cancel := workflow.WithCancel(ctx)
			cancelHeartbeatTimer = cancel

			heartbeatTimeout := workflow.NewTimer(timerCtx, 2*time.Minute)
			selector.AddFuture(heartbeatTimeout, func(f workflow.Future) {
				// Si el contexto fue cancelado (heartbeat llegó a tiempo), f.Get devuelve error.
				// Solo actuar si el timer expiró realmente.
				if f.Get(timerCtx, nil) != nil {
					return // timer cancelado — heartbeat llegó antes
				}
				timeSinceLastHeartbeat := workflow.Now(ctx).Sub(lastHeartbeat)
				if timeSinceLastHeartbeat > 2*time.Minute {
					logger.Warn("Heartbeat timeout detected",
						"since_last", timeSinceLastHeartbeat)
					// IDLE en lugar de DEGRADED — permite relaunch directo sin intervención manual
					state.State = types.StateIdle
					state.ErrorMessage = "heartbeat timeout"
					state.SentinelRunning = false
					state.LastUpdate = workflow.Now(ctx)
					cancelHeartbeatTimer = nil
				}
			})
		}

		selector.Select(ctx)

		// El workflow solo termina definitivamente si el estado es TERMINATED.
		// TERMINATED es reservado para eliminación permanente del perfil — nunca para shutdown normal.
		if state.State == types.StateTerminated {
			logger.Info("ProfileLifecycleWorkflow terminated definitively", "profile_id", input.ProfileID)
			return nil
		}

		// ContinueAsNew periódico para evitar el límite de ~50k eventos de historial de Temporal.
		// Solo se triggerea entre sesiones (Sentinel detenido) para no cortar un run activo a mitad.
		// El estado completo se preserva en ProfileLifecycleInput para el nuevo run.
		if launchCount >= maxLaunchesBeforeReset && !state.SentinelRunning {
			logger.Info("ContinueAsNew triggered — resetting history",
				"launch_count", launchCount,
				"profile_id", input.ProfileID)

			return workflow.NewContinueAsNewError(ctx, ProfileLifecycleWorkflow, types.ProfileLifecycleInput{
				ProfileID:   input.ProfileID,
				Environment: input.Environment,
				LaunchCount: launchCount,
			})
		}
	}
}

// RecoveryFlowWorkflow — Child workflow para intentar recuperar un perfil degraded
func RecoveryFlowWorkflow(ctx workflow.Context, input types.RecoveryFlowInput) (types.RecoveryFlowResult, error) {
	logger := workflow.GetLogger(ctx)
	logger.Info("RecoveryFlowWorkflow started",
		"profile_id", input.ProfileID,
		"failure_type", input.FailureType)

	activityOptions := workflow.ActivityOptions{
		StartToCloseTimeout: 3 * time.Minute,
		RetryPolicy: &temporal.RetryPolicy{
			MaximumAttempts: 2,
		},
	}
	ctx = workflow.WithActivityOptions(ctx, activityOptions)

	workflow.Sleep(ctx, 10*time.Second)

	logger.Info("Recovery: checking system health")

	result := types.RecoveryFlowResult{
		Success:  true,
		NewState: types.StateRunning,
	}

	logger.Info("RecoveryFlowWorkflow completed", "success", result.Success)
	return result, nil
}