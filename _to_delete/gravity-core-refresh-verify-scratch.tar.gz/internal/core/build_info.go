package core

import (
	"strconv"
)

// Auto-generated/injected during build - DO NOT EDIT
// build-component.sh injects these via -ldflags -X:
//   -X nucleus/internal/core.buildNumber=<N>
//   -X nucleus/internal/core.BuildDate=<date>
//   -X nucleus/internal/core.BuildTime=<time>

var buildNumber string = "0"

var BuildDate string = "1970-01-01"
var BuildTime string = "00:00:00"

// BuildNumber returns the build number as int.
// Injected as a string by the linker; parsed once at call time.
func BuildNumber() int {
	n, err := strconv.Atoi(buildNumber)
	if err != nil {
		return 0
	}
	return n
}
