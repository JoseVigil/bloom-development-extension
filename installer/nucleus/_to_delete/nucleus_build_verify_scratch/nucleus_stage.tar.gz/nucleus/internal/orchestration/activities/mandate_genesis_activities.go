// internal/orchestration/activities/mandate_genesis_activities.go
package activities

import (
	"bytes"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"time"

	"nucleus/internal/core"
)

// ─────────────────────────────────────────────────────────────────────────
// CAMBIO esta sesión: se agrega ScaffoldMode para distinguir Fase 2
// (dry_run: solo análisis, escribe domain_proposal.json, no toca
// .scaffold/) de Fase 4 (real: escribe .scaffold/.domain_{name}/ de
// verdad). Antes de este cambio, ScaffoldDomainActivity era literalmente
// la misma función sin ninguna rama para las dos fases (confirmado en
// turno anterior) — este es el fix de esa inconsistencia.
//
// SIGUE PENDIENTE, no resuelto en este cambio: la llamada real a Brain
// (TODO original, TCP puerto 5678) no se implementa acá — sigue sin
// existir ese cliente. dry_run hoy sigue devolviendo un solo dominio
// (input.Project), no clustering real de Brain. Este cambio ordena el
// ciclo de vida (dry_run vs real, y cuándo se escribe qué), no agrega
// clustering — son problemas distintos.
//
// RUTA DE ESCRITURA: uso {mandatesRoot}/{mandateID}/domain_proposal.json
// (plano), el mismo layout que ya usan mandate.go / mandate_watcher.go /
// mandate_genesis_domains_cmd.go para mandate.json y mandate_state.json.
// NO uso la ruta anidada .bloom/.intents/.gen/.../.analysis/ que muestra
// bloom_project_tree_gen.txt — esa convención nunca se confirmó contra
// ningún escritor Go real que haya visto, y mezclar dos layouts de
// filesystem sin confirmación sería inventar. Si el layout anidado es el
// correcto, hay que decirlo explícitamente y este path cambia.
// ─────────────────────────────────────────────────────────────────────────

type ScaffoldMode string

const (
	ScaffoldModeDryRun ScaffoldMode = "dry_run" // Fase 2: solo análisis
	ScaffoldModeReal   ScaffoldMode = "real"    // Fase 4: escritura real
)

type ScaffoldDomainInput struct {
	MandateID    string
	ActionID     string
	DomainName   string
	Files        []string
	Mode         ScaffoldMode
	MandatesRoot string // requerido en ambos modos: dónde vive {mandateID}/
}

type ScaffoldDomainResult struct {
	ResultRef string // path relativo a .intents/.gen/.../report.json (dry_run) o al scaffold escrito (real)
	// Domains — CAMPO NUEVO esta sesión. Solo poblado en Mode=dry_run: la
	// misma lista que se acaba de escribir en domain_proposal.json. Se
	// devuelve acá porque el workflow (caller) NO puede leer archivos por
	// su cuenta — el código de un Workflow de Temporal debe ser
	// determinista, toda I/O tiene que pasar por una Activity. Sin esto,
	// MandateBuildWorkflow no tendría forma de construir
	// candidateDomains para pasarle a PersistHumanSyncActivity más
	// adelante sin una activity de lectura aparte.
	Domains []ProposedDomain
}

// ProposedDomain — un elemento de domains[] en domain_proposal.json.
//
// CAMBIO esta sesión (corrección de arquitectura sobre el turno anterior):
// id YA NO es igual a domainName. domainName es mutable (rename es
// operación obligatoria del diseño, confirmado en
// bloom-mandate-arquitectura-genesis-conductor.md) — un id derivado de un
// campo mutable rompe trazabilidad en cuanto alguien renombra después de
// que ya se emitieron eventos o se escribieron carpetas con ese id. El id
// ahora se genera una sola vez acá (dom_{slug}_{sufijo}) y no cambia
// aunque domainName cambie después.
//
// suggestedActionCount se agrega al shape en este turno (no estaba en la
// versión anterior) — hoy siempre vale 1 porque no hay clustering real
// (mismo placeholder que cohesionScore: 1.0), ver nota en scaffoldDryRun.
type ProposedDomain struct {
	ID                   string   `json:"id"`
	DomainName           string   `json:"domainName"`
	CohesionScore        float64  `json:"cohesionScore"`
	SuggestedActionCount int      `json:"suggestedActionCount"`
	Files                []string `json:"files"`
}

var slugNonAlnum = regexp.MustCompile(`[^a-z0-9]+`)

// domainSlug normaliza domainName para el prefijo legible del id: minúsculas,
// separadores no alfanuméricos colapsados a "_", sin guiones al borde.
// "Billing" -> "billing", "User Auth!!" -> "user_auth".
func domainSlug(domainName string) string {
	s := strings.ToLower(strings.TrimSpace(domainName))
	s = slugNonAlnum.ReplaceAllString(s, "_")
	s = strings.Trim(s, "_")
	if s == "" {
		s = "domain"
	}
	return s
}

// randomSuffix genera el sufijo corto que evita colisión entre dos
// dominios cuyo nombre normalice al mismo slug (p. ej. "Billing" y
// "billing " en el mismo proposal). 4 bytes hex = 8 caracteres es más de
// lo que pediste en el ejemplo (a3f1, 4 chars) — uso 2 bytes (4 hex chars)
// para calzar exacto con el ejemplo dado.
func randomSuffix() string {
	b := make([]byte, 2)
	if _, err := rand.Read(b); err != nil {
		// no debería pasar con crypto/rand, pero si pasa, un id sin
		// sufijo random sigue siendo mejor que un error duro acá — el
		// riesgo de colisión sube, no se cae todo el proposal por esto.
		return "0000"
	}
	return hex.EncodeToString(b)
}

// newDomainID arma el id estable definitivo: dom_{slug}_{sufijo}.
func newDomainID(domainName string) string {
	return fmt.Sprintf("dom_%s_%s", domainSlug(domainName), randomSuffix())
}

type DomainProposal struct {
	Status  string           `json:"status"` // "proposed"
	Domains []ProposedDomain `json:"domains"`
}

// ScaffoldDomainActivity habla por TCP (puerto 5678) con Brain para generar
// código de dominio. TODO original sigue sin resolver: esta función no
// llama a Brain todavía (mismo TODO que ya existía: "mismo patrón que
// sentinel_activities.go usa para invocar Brain" — sigo sin ese archivo,
// no lo invento).
func ScaffoldDomainActivity(input ScaffoldDomainInput) (ScaffoldDomainResult, error) {
	if input.MandatesRoot == "" {
		return ScaffoldDomainResult{}, fmt.Errorf("ScaffoldDomainActivity: MandatesRoot vacío para mandate %s", input.MandateID)
	}

	publishMandateEvent("mandate:action:started", map[string]interface{}{
		"mandateId":  input.MandateID,
		"actionId":   input.ActionID,
		"domainName": input.DomainName,
		"mode":       string(input.Mode),
		"startedAt":  time.Now().Format(time.RFC3339),
	})

	var resultRef string
	var domains []ProposedDomain
	var err error

	switch input.Mode {
	case ScaffoldModeReal:
		resultRef, err = scaffoldReal(input)
	case ScaffoldModeDryRun, "":
		// "" se trata como dry_run por compatibilidad hacia atrás con
		// callers que todavía no setean Mode explícitamente — no rompe
		// silenciosamente, pero tampoco explota. Si se prefiere que sea
		// error duro, es un cambio de una línea.
		resultRef, domains, err = scaffoldDryRun(input)
	default:
		err = fmt.Errorf("ScaffoldDomainActivity: Mode %q desconocido", input.Mode)
	}

	if err != nil {
		publishMandateEvent("mandate:action:failed", map[string]interface{}{
			"mandateId":  input.MandateID,
			"actionId":   input.ActionID,
			"domainName": input.DomainName,
			"error":      err.Error(),
		})
		return ScaffoldDomainResult{}, err
	}

	completedPayload := map[string]interface{}{
		"mandateId":   input.MandateID,
		"actionId":    input.ActionID,
		"domainName":  input.DomainName,
		"resultRef":   resultRef,
		"completedAt": time.Now().Format(time.RFC3339),
	}
	// domains — CAMPO NUEVO esta sesión, gap encontrado por Frontend
	// después de armar el flujo completo: sin esto, la UI nunca ve el id
	// real (dom_{slug}_{sufijo}) que scaffoldDryRun generó, y no tiene
	// cómo devolverlo en MandateValidateSignal.Domains[].ID —
	// SignMandateActivity fallaría al firmar por "confirmedDomainIds
	// referencia domainId ausente en candidateDomains". Solo se agrega la
	// key en Mode=dry_run (domains no vacío); en Mode=real se omite del
	// todo en vez de mandar "domains": null — no hay una propuesta nueva
	// que anunciar en ese punto.
	if len(domains) > 0 {
		completedPayload["domains"] = domains
	}
	publishMandateEvent("mandate:action:completed", completedPayload)
	return ScaffoldDomainResult{ResultRef: resultRef, Domains: domains}, nil
}

// scaffoldDryRun es Fase 2: NO escribe .scaffold/, solo domain_proposal.json.
// Hoy sigue devolviendo un único dominio (input.Project vía input.DomainName)
// porque no hay clustering real de Brain — ver TODO al inicio del archivo.
// La estructura ya es domains[] (array), lista para cuando haya N reales.
func scaffoldDryRun(input ScaffoldDomainInput) (string, []ProposedDomain, error) {
	dir := filepath.Join(input.MandatesRoot, input.MandateID)
	if err := os.MkdirAll(dir, 0755); err != nil {
		return "", nil, fmt.Errorf("no pude crear %s: %w", dir, err)
	}

	proposal := DomainProposal{
		Status: "proposed",
		Domains: []ProposedDomain{
			{
				ID:                   newDomainID(input.DomainName),
				DomainName:           input.DomainName,
				CohesionScore:        1.0, // sin clustering real, cohesión no significa nada — placeholder explícito
				SuggestedActionCount: 1,   // idem — sin clustering real, siempre 1
				Files:                input.Files,
			},
		},
	}

	data, err := json.MarshalIndent(proposal, "", "  ")
	if err != nil {
		return "", nil, fmt.Errorf("no pude serializar domain_proposal.json: %w", err)
	}

	path := filepath.Join(dir, "domain_proposal.json")
	if err := os.WriteFile(path, data, 0644); err != nil {
		return "", nil, fmt.Errorf("no pude escribir domain_proposal.json: %w", err)
	}

	return "domain_proposal.json", proposal.Domains, nil
}

// scaffoldReal es Fase 4: escribe la carpeta física del dominio.
//
// INCOMPLETO A PROPÓSITO: solo crea el directorio y un marker mínimo.
// bloom_project_tree_gen.txt lista .gen.json, .gen_state.json,
// .semantic_scaffold.json, .context_gen_plan.json y .files/ dentro de cada
// .domain_{name}/ — no tengo el schema de ninguno de esos archivos
// confirmado contra código real (mismo problema que domain_proposal.json:
// existen en la documentación de diseño, no vi ningún writer). Escribir
// contenido inventado para esos archivos sería el mismo error que ya
// evitamos con domainId — así que no lo hago. Esto deja el scaffold real
// "creado pero vacío", explícitamente marcado, no simulado como completo.
func scaffoldReal(input ScaffoldDomainInput) (string, error) {
	domainDir := filepath.Join(input.MandatesRoot, input.MandateID, "scaffold", "domain_"+input.DomainName)
	if err := os.MkdirAll(domainDir, 0755); err != nil {
		return "", fmt.Errorf("no pude crear %s: %w", domainDir, err)
	}

	marker := map[string]interface{}{
		"domainName":   input.DomainName,
		"files":        input.Files,
		"scaffoldedAt": time.Now().Format(time.RFC3339),
		"note": "contenido real de .gen.json/.semantic_scaffold.json/etc. no implementado — " +
			"schema no confirmado contra código, ver comentario de scaffoldReal",
	}
	data, err := json.MarshalIndent(marker, "", "  ")
	if err != nil {
		return "", fmt.Errorf("no pude serializar marker de %s: %w", input.DomainName, err)
	}
	markerPath := filepath.Join(domainDir, "_INCOMPLETE_SCAFFOLD.json")
	if err := os.WriteFile(markerPath, data, 0644); err != nil {
		return "", fmt.Errorf("no pude escribir marker de %s: %w", input.DomainName, err)
	}

	return filepath.Join("scaffold", "domain_"+input.DomainName), nil
}

// PublishMandateEventActivity es la versión "activity" para eventos que el
// workflow mismo dispara (no una activity de negocio), como all_complete.
func PublishMandateEventActivity(event string, data map[string]interface{}) error {
	publishMandateEvent(event, data)
	return nil
}

// publishMandateEvent hace POST al endpoint dual-emit del Control Plane
// (puerto 48215, el mismo que expone bootControlPlane en service.go).
func publishMandateEvent(event string, data map[string]interface{}) {
	body, _ := json.Marshal(map[string]interface{}{"event": event, "data": data})
	go func() {
		client := &http.Client{Timeout: 2 * time.Second}
		resp, err := client.Post("http://localhost:48215/internal/mandate-event",
			"application/json", bytes.NewBuffer(body))
		if err != nil {
			return
		}
		defer resp.Body.Close()
	}()
}

// ─────────────────────────────────────────────────────────────────────────
// IngestReceptionActivity — Fase 1 real (.reception/ de ing/, ver
// ING_Intent_Spec_v1_1.md §3). Reemplaza el hueco que existía antes en
// mandate_build_workflow.go, donde Fase 1 era una sola
// PublishMandateEventActivity sin ningún trabajo real detrás (confirmado en
// BLOOM_BISP_Session_Decisions_v1_1.md:330 — "no llama a Brain, no llama a
// Ollama, no toca ChromaDB"). El pulso "mandate:phase:ingest" sigue
// existiendo (la UI de /genesis lo espera como marcador de fase única, sin
// progreso incremental — ver bloom-conductor-genesis-v1_1.html), pero ahora
// se dispara DESPUÉS de que esta activity corrió de verdad, no en su lugar
// — ver el caller en mandate_build_workflow.go.
//
// Invoca `brain intent create --type ing` + `brain intent hydrate` como
// subprocess: mismo patrón D-15 que runBrainCreate (governance/create.go)
// — "mismo patrón que ya usa el plugin de VS Code, sin pasar por Sentinel",
// no un cliente TCP nuevo. A diferencia de runBrainCreate (que deja
// stdout/stderr fluir directo porque nadie necesita el resultado de
// vuelta), acá sí hace falta capturar y parsear stdout: hydrate necesita el
// intent_id que create devolvió.
//
// domain_baseline mapea 1:1 desde MandateType — único origen confirmado
// contra createGenesisMandate (commands/mandate.go): "genesis" -> "empty"
// (Genesis puro), "domain_expansion" -> "existing" (incorpora sobre un
// baseGenesisId ya existente). No hay un tercer caso documentado en
// ninguna parte del código leído — cualquier otro valor es error duro, no
// un default silencioso.
//
// Archivos: --docs en `mandate genesis` los copia a
// {MandatesRoot}/{MandateID}/docs/ (ver copyDocsInto, commands/mandate.go).
// --docs es opcional ahí — si no se pasó, ese directorio directamente no
// existe. Se trata como 0 archivos, no como fallo: confirmado contra
// _write_ing_reception_content en intent_manager.py, que no falla con
// files_to_process vacío (.rawbase.json/.rawbase_index.json quedan con
// arrays vacíos y la fase igual cierra vía close_phaseless_act()).
//
// --nucleus-path se pasa SIEMPRE explícito. Sin esto, brain
// (_find_bloom_project) busca un ".bloom/" subiendo desde el cwd del
// proceso de nucleus, que no tiene por qué coincidir con el Nucleus activo
// del mandate. MandatesRoot ya vive en
// <workspace>/.bloom/.nucleus-{org}/.mandates, por lo que su padre directo
// es la raíz Nucleus que debe contener .intents/.
// ─────────────────────────────────────────────────────────────────────────

type IngestReceptionInput struct {
	MandateID    string
	MandateType  string // "genesis" | "domain_expansion" — ver createGenesisMandate
	Project      string
	MandatesRoot string
}

type IngestReceptionResult struct {
	IntentID   string
	FolderName string
	FilesCount int
}

func resolveNucleusRootFromMandatesRoot(mandatesRoot string) string {
	return filepath.Dir(filepath.Clean(mandatesRoot))
}

// brainCLIResult — shape mínimo compartido por la salida --json de brain
// (confirmado contra create.py/hydrate.py: {"status":"success"|"error",
// "operation":"...", "data":{...}} en éxito, {"status":"error","message":
// "..."} en fallo). Solo modela los campos que esta activity necesita, no
// el contrato completo de brain.
type brainCLIResult struct {
	Status    string                 `json:"status"`
	Operation string                 `json:"operation"`
	Message   string                 `json:"message"`
	Data      map[string]interface{} `json:"data"`
	Error     *brainCLIErrorEnvelope `json:"error,omitempty"`
	ExitCode  *int                   `json:"exit_code,omitempty"`
}

type brainCLIErrorEnvelope struct {
	Code      string                 `json:"code"`
	Message   string                 `json:"message"`
	Retryable bool                   `json:"retryable"`
	Details   map[string]interface{} `json:"details"`
}

// BrainCLIError preserva el contrato machine-readable de los comandos de
// efectos. Un exit code 2 no determina por sí solo si el error es Typer o
// protocolo: RunBrainIntentJSON intenta decodificar stdout primero.
type BrainCLIError struct {
	Command   string
	ExitCode  int
	Code      string
	Message   string
	Retryable bool
	Details   map[string]interface{}
	Stdout    string
	Stderr    string
}

func (e *BrainCLIError) Error() string {
	if e.Code != "" {
		return fmt.Sprintf("brain %s falló (exit=%d, code=%s): %s", e.Command, e.ExitCode, e.Code, e.Message)
	}
	return fmt.Sprintf("brain %s falló (exit=%d): %s", e.Command, e.ExitCode, e.Message)
}

type brainCommandRunner func(brainPath string, args []string) (stdout, stderr []byte, exitCode int, runErr error)

func execBrainCommand(brainPath string, args []string) ([]byte, []byte, int, error) {
	cmd := exec.Command(brainPath, args...)
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	err := cmd.Run()
	exitCode := 0
	if err != nil {
		exitCode = -1
		if exitErr, ok := err.(*exec.ExitError); ok {
			exitCode = exitErr.ExitCode()
		}
	}
	return stdout.Bytes(), stderr.Bytes(), exitCode, err
}

type BSIPTurnRef struct {
	NucleusPath string
	IntentID    string
	IntentType  string
	Stage       string
	TurnID      string
}

type MarkBSIPEffectAppliedInput struct {
	BSIPTurnRef
	EffectID string
	Evidence map[string]interface{}
}

type BSIPTurnCommandResult struct {
	IntentID         string
	IntentType       string
	Stage            string
	TurnID           string
	EffectID         string
	Obligation       string
	EffectStatus     string
	LedgerState      string
	LedgerPath       string
	EffectsDigest    string
	Committed        bool
	AlreadyCommitted bool
	PhaseActive      string
	AlreadyAdvanced  bool
	StateAdvanced    bool
}

// IngestReceptionActivity hidrata .reception/ de un intent 'ing' recién
// creado a partir de los docs que copyDocsInto dejó en el mandate.
func IngestReceptionActivity(input IngestReceptionInput) (IngestReceptionResult, error) {
	if input.MandatesRoot == "" {
		return IngestReceptionResult{}, fmt.Errorf("IngestReceptionActivity: MandatesRoot vacío para mandate %s", input.MandateID)
	}

	var domainBaseline string
	switch input.MandateType {
	case "genesis":
		domainBaseline = "empty"
	case "domain_expansion":
		domainBaseline = "existing"
	default:
		return IngestReceptionResult{}, fmt.Errorf(
			"IngestReceptionActivity: MandateType %q desconocido para mandate %s — esperaba 'genesis' o 'domain_expansion'",
			input.MandateType, input.MandateID,
		)
	}

	// nucleusRoot conserva la organización activa resuelta por el watcher:
	// <workspace>/.bloom/.nucleus-{org}/.mandates ->
	// <workspace>/.bloom/.nucleus-{org}.
	nucleusRoot := resolveNucleusRootFromMandatesRoot(input.MandatesRoot)

	docsDir := filepath.Join(input.MandatesRoot, input.MandateID, "docs")
	var docFiles []string
	if entries, err := os.ReadDir(docsDir); err == nil {
		for _, e := range entries {
			if !e.IsDir() {
				docFiles = append(docFiles, filepath.Join(docsDir, e.Name()))
			}
		}
	}
	// err != nil acá (típicamente "no existe") no es un fallo — --docs es
	// opcional en `mandate genesis`, ver nota arriba.

	brainPath, err := core.ResolveBrainPath()
	if err != nil {
		// Mismo fallback que runBrainCreate (governance/create.go): intentar
		// "brain" en PATH del sistema en vez de fallar duro acá.
		brainPath = "brain"
	}

	createArgs := []string{
		"--json", "intent", "create",
		"--type", "ing",
		"--name", input.Project,
		"--mandate-id", input.MandateID,
		"--domain-baseline", domainBaseline,
		"--nucleus-path", nucleusRoot,
	}
	createOut, err := runBrainIntentJSON(brainPath, createArgs)
	if err != nil {
		return IngestReceptionResult{}, fmt.Errorf("IngestReceptionActivity: brain intent create falló (mandate %s): %w", input.MandateID, err)
	}
	intentID, _ := createOut.Data["intent_id"].(string)
	folderName, _ := createOut.Data["folder_name"].(string)
	if intentID == "" {
		return IngestReceptionResult{}, fmt.Errorf(
			"IngestReceptionActivity: brain intent create no devolvió intent_id (mandate %s)", input.MandateID,
		)
	}

	hydrateArgs := []string{
		"--json", "intent", "hydrate",
		"--id", intentID,
		"--nucleus-path", nucleusRoot,
	}
	if len(docFiles) > 0 {
		hydrateArgs = append(hydrateArgs, "--files", strings.Join(docFiles, ","))
	}
	if _, err := runBrainIntentJSON(brainPath, hydrateArgs); err != nil {
		return IngestReceptionResult{}, fmt.Errorf("IngestReceptionActivity: brain intent hydrate falló (intent %s, mandate %s): %w", intentID, input.MandateID, err)
	}
	return IngestReceptionResult{
		IntentID:   intentID,
		FolderName: folderName,
		FilesCount: len(docFiles),
	}, nil
}

// runBrainIntentJSON ejecuta brain con --json y parsea stdout como
// brainCLIResult. stdout y stderr se capturan por separado (a diferencia de
// runBrainCreate, que los deja fluir directo) porque el caller necesita
// leer "data" de la respuesta, no solo reenviarla.
func runBrainIntentJSON(brainPath string, args []string) (*brainCLIResult, error) {
	return runBrainIntentJSONWithRunner(brainPath, args, execBrainCommand)
}

func runBrainIntentJSONWithRunner(brainPath string, args []string, runner brainCommandRunner) (*brainCLIResult, error) {
	stdout, stderr, processExitCode, runErr := runner(brainPath, args)
	var parsed brainCLIResult
	jsonErr := json.Unmarshal(stdout, &parsed)
	command := strings.Join(args, " ")
	trimmedStdout := strings.TrimSpace(string(stdout))
	trimmedStderr := strings.TrimSpace(string(stderr))
	if jsonErr != nil || parsed.Status == "" {
		if runErr != nil {
			message := trimmedStderr
			if message == "" {
				message = runErr.Error()
			}
			return nil, &BrainCLIError{
				Command: command, ExitCode: processExitCode, Code: "UNSTRUCTURED_CLI_ERROR",
				Message: message, Retryable: false, Stdout: trimmedStdout, Stderr: trimmedStderr,
			}
		}
		return nil, &BrainCLIError{
			Command: command, ExitCode: processExitCode, Code: "INVALID_JSON_RESPONSE",
			Message:   fmt.Sprintf("no pude parsear stdout de brain como JSON: %v", jsonErr),
			Retryable: false, Stdout: trimmedStdout, Stderr: trimmedStderr,
		}
	}

	if parsed.Status == "error" && parsed.Error != nil && parsed.Error.Code != "" && parsed.ExitCode != nil {
		if processExitCode != *parsed.ExitCode {
			return &parsed, &BrainCLIError{
				Command: command, ExitCode: processExitCode, Code: "PROTOCOL_EXIT_CODE_MISMATCH",
				Message:   fmt.Sprintf("process exit code %d differs from envelope exit_code %d", processExitCode, *parsed.ExitCode),
				Retryable: false, Details: parsed.Error.Details, Stdout: trimmedStdout, Stderr: trimmedStderr,
			}
		}
		return &parsed, &BrainCLIError{
			Command: command, ExitCode: *parsed.ExitCode, Code: parsed.Error.Code,
			Message: parsed.Error.Message, Retryable: parsed.Error.Retryable,
			Details: parsed.Error.Details, Stdout: trimmedStdout, Stderr: trimmedStderr,
		}
	}

	if runErr != nil {
		return &parsed, &BrainCLIError{
			Command: command, ExitCode: processExitCode, Code: "PROTOCOL_STATUS_MISMATCH",
			Message:   "process failed but stdout did not contain a structured error envelope",
			Retryable: false, Stdout: trimmedStdout, Stderr: trimmedStderr,
		}
	}

	if parsed.Status != "success" {
		msg := parsed.Message
		if msg == "" {
			msg = trimmedStderr
		}
		return &parsed, &BrainCLIError{
			Command: command, ExitCode: processExitCode, Code: "INVALID_PROTOCOL_STATUS",
			Message:   fmt.Sprintf("brain devolvió status=%q: %s", parsed.Status, msg),
			Retryable: false, Stdout: trimmedStdout, Stderr: trimmedStderr,
		}
	}

	return &parsed, nil
}

func validateBSIPTurnRef(ref BSIPTurnRef) error {
	if strings.TrimSpace(ref.NucleusPath) == "" || strings.TrimSpace(ref.IntentID) == "" ||
		strings.TrimSpace(ref.IntentType) == "" || strings.TrimSpace(ref.Stage) == "" || strings.TrimSpace(ref.TurnID) == "" {
		return fmt.Errorf("nucleus_path, intent_id, intent_type, stage y turn_id son obligatorios")
	}
	if ref.IntentType != "ing" && ref.IntentType != "dis" {
		return fmt.Errorf("intent_type %q inválido: esperaba ing o dis", ref.IntentType)
	}
	if ref.Stage != "consolidation" && ref.Stage != "ratification" {
		return fmt.Errorf("stage %q inválido: esperaba consolidation o ratification", ref.Stage)
	}
	turn, err := strconv.Atoi(ref.TurnID)
	if err != nil || turn < 1 {
		return fmt.Errorf("turn_id %q inválido: debe ser un entero positivo", ref.TurnID)
	}
	return nil
}

func effectCommandArgs(command string, ref BSIPTurnRef) []string {
	return []string{
		"--json", "intent", command,
		"--nucleus-path", ref.NucleusPath,
		"--intent-id", ref.IntentID,
		"--stage", ref.Stage,
		"--turn-id", ref.TurnID,
	}
}

func decodeBSIPTurnCommandResult(parsed *brainCLIResult, expected BSIPTurnRef) (BSIPTurnCommandResult, error) {
	getString := func(key string) string {
		value, _ := parsed.Data[key].(string)
		return value
	}
	result := BSIPTurnCommandResult{
		IntentID: getString("intent_id"), IntentType: getString("intent_type"),
		Stage: getString("stage"), TurnID: getString("turn_id"),
		EffectID: getString("effect_id"), Obligation: getString("obligation"),
		EffectStatus: getString("effect_status"), LedgerState: getString("ledger_state"),
		LedgerPath: getString("ledger_path"), EffectsDigest: getString("effects_digest"),
		PhaseActive: getString("phase_active"),
	}
	result.Committed, _ = parsed.Data["committed"].(bool)
	result.AlreadyCommitted, _ = parsed.Data["already_committed"].(bool)
	result.AlreadyAdvanced, _ = parsed.Data["already_advanced"].(bool)
	result.StateAdvanced, _ = parsed.Data["state_advanced"].(bool)
	if result.IntentID != expected.IntentID || result.IntentType != expected.IntentType ||
		result.Stage != expected.Stage || result.TurnID != expected.TurnID {
		return BSIPTurnCommandResult{}, fmt.Errorf(
			"correlación Brain inválida: esperado intent_id=%q intent_type=%q stage=%q turn_id=%q; recibido intent_id=%q intent_type=%q stage=%q turn_id=%q",
			expected.IntentID, expected.IntentType, expected.Stage, expected.TurnID,
			result.IntentID, result.IntentType, result.Stage, result.TurnID,
		)
	}
	return result, nil
}

func resolveBrainEffectCommandPath() string {
	brainPath, err := core.ResolveBrainPath()
	if err != nil {
		return "brain"
	}
	return brainPath
}

func MarkBSIPEffectApplied(input MarkBSIPEffectAppliedInput) (BSIPTurnCommandResult, error) {
	return markBSIPEffectAppliedWithRunner(resolveBrainEffectCommandPath(), input, execBrainCommand)
}

func markBSIPEffectAppliedWithRunner(brainPath string, input MarkBSIPEffectAppliedInput, runner brainCommandRunner) (BSIPTurnCommandResult, error) {
	if err := validateBSIPTurnRef(input.BSIPTurnRef); err != nil {
		return BSIPTurnCommandResult{}, err
	}
	if strings.TrimSpace(input.EffectID) == "" {
		return BSIPTurnCommandResult{}, fmt.Errorf("effect_id es obligatorio")
	}
	if len(input.Evidence) == 0 {
		return BSIPTurnCommandResult{}, fmt.Errorf("evidence debe ser un objeto JSON no vacío producido por el verificador")
	}
	evidenceJSON, err := json.Marshal(input.Evidence)
	if err != nil {
		return BSIPTurnCommandResult{}, fmt.Errorf("no pude serializar evidence: %w", err)
	}
	args := append(effectCommandArgs("mark-effect-applied", input.BSIPTurnRef),
		"--effect-id", input.EffectID, "--evidence-json", string(evidenceJSON))
	parsed, err := runBrainIntentJSONWithRunner(brainPath, args, runner)
	if err != nil {
		return BSIPTurnCommandResult{}, err
	}
	result, err := decodeBSIPTurnCommandResult(parsed, input.BSIPTurnRef)
	if err != nil {
		return BSIPTurnCommandResult{}, err
	}
	if result.EffectID != input.EffectID || result.EffectStatus != "applied" {
		return BSIPTurnCommandResult{}, fmt.Errorf("respuesta mark-effect-applied inválida: effect_id=%q effect_status=%q", result.EffectID, result.EffectStatus)
	}
	return result, nil
}

func CommitBSIPTurn(ref BSIPTurnRef) (BSIPTurnCommandResult, error) {
	return commitBSIPTurnWithRunner(resolveBrainEffectCommandPath(), ref, execBrainCommand)
}

func commitBSIPTurnWithRunner(brainPath string, ref BSIPTurnRef, runner brainCommandRunner) (BSIPTurnCommandResult, error) {
	if err := validateBSIPTurnRef(ref); err != nil {
		return BSIPTurnCommandResult{}, err
	}
	parsed, err := runBrainIntentJSONWithRunner(brainPath, effectCommandArgs("commit-turn", ref), runner)
	if err != nil {
		return BSIPTurnCommandResult{}, err
	}
	result, err := decodeBSIPTurnCommandResult(parsed, ref)
	if err != nil {
		return BSIPTurnCommandResult{}, err
	}
	if !result.Committed {
		return BSIPTurnCommandResult{}, fmt.Errorf("respuesta commit-turn inválida: committed=false")
	}
	return result, nil
}

func AdvanceBSIPTurn(ref BSIPTurnRef) (BSIPTurnCommandResult, error) {
	return advanceBSIPTurnWithRunner(resolveBrainEffectCommandPath(), ref, execBrainCommand)
}

func advanceBSIPTurnWithRunner(brainPath string, ref BSIPTurnRef, runner brainCommandRunner) (BSIPTurnCommandResult, error) {
	if err := validateBSIPTurnRef(ref); err != nil {
		return BSIPTurnCommandResult{}, err
	}
	parsed, err := runBrainIntentJSONWithRunner(brainPath, effectCommandArgs("advance-turn", ref), runner)
	if err != nil {
		return BSIPTurnCommandResult{}, err
	}
	result, err := decodeBSIPTurnCommandResult(parsed, ref)
	if err != nil {
		return BSIPTurnCommandResult{}, err
	}
	if !result.StateAdvanced {
		return BSIPTurnCommandResult{}, fmt.Errorf("respuesta advance-turn inválida: state_advanced=false")
	}
	return result, nil
}
