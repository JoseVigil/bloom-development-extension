package temporal

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"
	"time"

	"go.temporal.io/sdk/activity"
	"go.temporal.io/sdk/client"
	"go.temporal.io/sdk/worker"

	"github.com/spf13/cobra"
	"nucleus/internal/core"
	"nucleus/internal/mandates"
	"nucleus/internal/orchestration/activities"
	"nucleus/internal/orchestration/temporal/bootstrap"
	temporalworkflows "nucleus/internal/orchestration/temporal/workflows"
)

// Worker envuelve el worker de Temporal
type Worker struct {
	worker worker.Worker
}

// NewWorker crea un nuevo worker
func NewWorker(c client.Client, taskQueue string) *Worker {
	w := worker.New(c, taskQueue, worker.Options{})
	return &Worker{worker: w}
}

// RegisterWorkflow registra un workflow
func (w *Worker) RegisterWorkflow(workflow interface{}) {
	w.worker.RegisterWorkflow(workflow)
}

// RegisterActivity registra una activity
func (w *Worker) RegisterActivity(activity interface{}) {
	w.worker.RegisterActivity(activity)
}

type activityRegistrar interface {
	RegisterActivity(interface{})
}

type namedActivityRegistrar interface {
	RegisterActivityWithOptions(interface{}, activity.RegisterOptions)
}

// registerMandateGenesisSignatureActivities mantiene agrupado el wiring
// productivo exclusivo de Human Sync y firma. No registra adaptadores BSIP.
func registerMandateGenesisSignatureActivities(registrar activityRegistrar) {
	registrar.RegisterActivity(activities.PersistHumanSyncActivity)
	registrar.RegisterActivity(activities.SignMandateActivity)
	registrar.RegisterActivity(activities.PersistSignatureFailureActivity)
}

func registerGravityActivities(registrar namedActivityRegistrar) {
	registrar.RegisterActivityWithOptions(activities.ResolveActiveGravityActivity, activity.RegisterOptions{
		Name: "resolveActiveGravityActivity",
	})
}

// RegisterActivityWithOptions registra una activity con opciones personalizadas
func (w *Worker) RegisterActivityWithOptions(act interface{}, options activity.RegisterOptions) {
	w.worker.RegisterActivityWithOptions(act, options)
}

// Start inicia el worker
func (w *Worker) Start() error {
	return w.worker.Start()
}

// Stop detiene el worker
func (w *Worker) Stop() {
	w.worker.Stop()
}

// WorkerManager gestiona múltiples workers
type WorkerManager struct {
	workers []*Worker
	client  *Client
}

// NewWorkerManager crea un nuevo manager de workers
func NewWorkerManager(client *Client) *WorkerManager {
	return &WorkerManager{
		workers: make([]*Worker, 0),
		client:  client,
	}
}

// CreateWorker crea y registra un nuevo worker
func (wm *WorkerManager) CreateWorker(taskQueue string) *Worker {
	w := NewWorker(wm.client.GetClient(), taskQueue)
	wm.workers = append(wm.workers, w)
	return w
}

// StartAll inicia todos los workers
func (wm *WorkerManager) StartAll(ctx context.Context) error {
	for i, w := range wm.workers {
		if err := w.Start(); err != nil {
			return fmt.Errorf("failed to start worker %d: %w", i, err)
		}
	}
	return nil
}

// StopAll detiene todos los workers
func (wm *WorkerManager) StopAll() {
	for _, w := range wm.workers {
		w.Stop()
	}
}

// ───────────────────────────────────────────────────────────────────────────
// WORKER CAPABILITIES — registry file written on startup
// ───────────────────────────────────────────────────────────────────────────

// WorkerCapabilities describe exactamente qué workflows y activities maneja
// este worker. Se escribe en history/workers/capabilities_<PID>.json al arrancar
// y es leído por `nucleus workers list` para enriquecer el panel.
type WorkerCapabilities struct {
	PID          int      `json:"pid"`
	RegisteredAt string   `json:"registered_at"`
	TaskQueue    string   `json:"task_queue"`
	Workflows    []string `json:"workflows"`
	Activities   []string `json:"activities"`
}

// writeWorkerCapabilities escribe el registry de capabilities en disco.
// Path: <appDataDir>/history/workers/capabilities_<PID>.json
// Sobreescribe en cada arranque — siempre refleja el worker activo.
// Error es no-fatal: el worker arranca igual aunque falle la escritura.
func writeWorkerCapabilities(configDir string, taskQueue string, workflows, activities []string) {
	caps := WorkerCapabilities{
		PID:          os.Getpid(),
		RegisteredAt: time.Now().UTC().Format(time.RFC3339),
		TaskQueue:    taskQueue,
		Workflows:    workflows,
		Activities:   activities,
	}

	data, err := json.MarshalIndent(caps, "", "  ")
	if err != nil {
		fmt.Fprintf(os.Stderr, "[worker] WARNING: failed to marshal capabilities: %v\n", err)
		return
	}

	path := filepath.Join(configDir, fmt.Sprintf("capabilities_%d.json", caps.PID))
	if err := os.WriteFile(path, data, 0644); err != nil {
		fmt.Fprintf(os.Stderr, "[worker] WARNING: failed to write capabilities_%d.json: %v\n", caps.PID, err)
		return
	}
}

// ───────────────────────────────────────────────────────────────────────────
// PID HELPERS
// ───────────────────────────────────────────────────────────────────────────

// isPIDAlive verifica si un proceso con el PID dado está corriendo.
// En Windows, os.FindProcess siempre retorna éxito y Signal(0) no está
// implementado de forma confiable, por lo que se usa tasklist como
// mecanismo de verificación — funciona sin CGO ni imports externos.
// En macOS/Linux se usa kill -0 vía os.Process.Signal(0).
func isPIDAlive(pid int) bool {
	if runtime.GOOS == "windows" {
		out, err := exec.Command(
			"tasklist",
			"/FI", fmt.Sprintf("PID eq %d", pid),
			"/NH",
			"/FO", "CSV",
		).Output()
		if err != nil {
			return false
		}
		// tasklist devuelve una línea con el PID entre comillas si el proceso existe,
		// o "INFO: No tasks are running which match the specified criteria." si no.
		return strings.Contains(string(out), fmt.Sprintf(`"%d"`, pid))
	}
	// Unix/macOS: Signal(0) verifica existencia sin enviar señal real.
	proc, err := os.FindProcess(pid)
	if err != nil {
		return false
	}
	return proc.Signal(syscall.Signal(0)) == nil
}

// ───────────────────────────────────────────────────────────────────────────
// CLI COMMANDS
// ───────────────────────────────────────────────────────────────────────────

// exeName devuelve el nombre del ejecutable con la extensión correcta según
// la plataforma. En Windows agrega .exe; en macOS/Linux lo omite.
func exeName(base string) string {
	if runtime.GOOS == "windows" {
		return base + ".exe"
	}
	return base
}

func init() {
	core.RegisterCommand("ORCHESTRATION", workerStartCmd)
}

func workerStartCmd(c *core.Core) *cobra.Command {
	var taskQueue string

	cmd := &cobra.Command{
		Use:   "worker start",
		Short: "Inicia el worker de Temporal para procesar workflows",
		Long:  "Levanta un worker que escucha en la task queue y ejecuta workflows y activities registrados",
		Run: func(cmd *cobra.Command, args []string) {
			logger, err := core.InitLogger(&c.Paths, "ORCHESTRATION", false)
			if err != nil {
				fmt.Fprintf(os.Stderr, "[ERROR] Fallo al inicializar logger: %v\n", err)
				os.Exit(1)
			}
			defer logger.Close()

			logger.Info("Iniciando Temporal Worker...")
			logger.Info("Task Queue: %s", taskQueue)

			// ── PID file guard ───────────────────────────────────────────────
			// Evita que health --fix levante una segunda instancia mientras
			// el worker anterior todavía está corriendo.
			// Usa tasklist para verificar el PID en Windows — Signal(0) no
			// funciona de forma confiable en Windows sin CGO.
			pidDir := filepath.Join(filepath.Dir(c.Paths.LogsDir), "history", "workers")
			if err := os.MkdirAll(pidDir, 0755); err != nil {
				logger.Warning("⚠️  Failed to create pid dir: %v", err)
			}
			pidFile := filepath.Join(pidDir, "nucleus_worker.pid")

			if pidData, pidErr := os.ReadFile(pidFile); pidErr == nil {
				var existingPID int
				if _, scanErr := fmt.Sscanf(strings.TrimSpace(string(pidData)), "%d", &existingPID); scanErr == nil && existingPID > 0 {
					if isPIDAlive(existingPID) {
						logger.Warning("⚠️  Worker already running (PID %d) — exiting to avoid duplicate", existingPID)
						return
					}
				}
				logger.Info("Stale PID file found (%s) — previous worker gone, starting fresh", strings.TrimSpace(string(pidData)))
			}

			if err := os.WriteFile(pidFile, []byte(fmt.Sprintf("%d", os.Getpid())), 0644); err != nil {
				logger.Warning("⚠️  Failed to write PID file: %v", err)
			} else {
				logger.Info("PID file written (PID %d): %s", os.Getpid(), pidFile)
			}
			defer func() {
				os.Remove(pidFile)
				logger.Info("PID file removed: %s", pidFile)
			}()
			// ── fin PID file guard ───────────────────────────────────────────

			// ── capabilities stale cleanup ───────────────────────────────────
			// Al arrancar, eliminar los capabilities_<PID>.json de workers que
			// ya no están corriendo. El archivo del PID actual se escribe más
			// adelante en writeWorkerCapabilities — no hay riesgo de borrarlo acá.
			if entries, globErr := filepath.Glob(filepath.Join(pidDir, "capabilities_*.json")); globErr == nil {
				cleaned := 0
				for _, entry := range entries {
					base := filepath.Base(entry)
					var capPID int
					if _, parseErr := fmt.Sscanf(base, "capabilities_%d.json", &capPID); parseErr == nil {
						if !isPIDAlive(capPID) {
							if removeErr := os.Remove(entry); removeErr == nil {
								cleaned++
							}
						}
					}
				}
				if cleaned > 0 {
					logger.Info("Cleaned up %d stale capabilities file(s)", cleaned)
				}
			}
			// ── fin capabilities stale cleanup ───────────────────────────────

			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()

			temporalClient, err := NewClient(ctx, &c.Paths, false)
			if err != nil {
				logger.Error("Fallo al conectar con Temporal: %v", err)
				os.Exit(1)
			}
			defer temporalClient.Close()

			// Crear worker
			w := NewWorker(temporalClient.GetClient(), taskQueue)

			// ✅ REGISTRAR WORKFLOWS
			logger.Info("Registrando workflows...")

			// Workflow principal de ciclo de vida del perfil
			w.RegisterWorkflow(temporalworkflows.ProfileLifecycleWorkflow)

			// Recovery workflow
			w.RegisterWorkflow(temporalworkflows.RecoveryFlowWorkflow)

			// Workflows adicionales existentes
			w.RegisterWorkflow(temporalworkflows.StartOllamaWorkflow)
			w.RegisterWorkflow(temporalworkflows.VaultStatusWorkflow)
			w.RegisterWorkflow(temporalworkflows.ShutdownAllWorkflow)
			w.RegisterWorkflow(temporalworkflows.SeedWorkflow)

			// Workflow de onboarding navigate
			w.RegisterWorkflow(temporalworkflows.OnboardingWorkflow)

			// Workflow de system health (invocado por Schedule cada 60s)
			w.RegisterWorkflow(temporalworkflows.SystemHealthWorkflow)

			logger.Success("✅ Workflows registrados")

			// ✅ REGISTRAR ACTIVITIES
			logger.Info("Registrando activities...")

			// Construir paths usando PathConfig disponible
			logsDir := c.Paths.LogsDir
			nucleusExe := filepath.Join(c.Paths.BinDir, "nucleus", exeName("nucleus"))
			sentinelExe := filepath.Join(c.Paths.BinDir, "sentinel", exeName("sentinel"))

			// Verificar que sentinel existe
			if _, err := os.Stat(sentinelExe); os.IsNotExist(err) {
				logger.Warning("⚠️  Sentinel executable not found at: %s", sentinelExe)
				logger.Info("Worker will start but activities will fail without sentinel")
			}

			// Crear instancia de SentinelActivities
			sentinelAct := activities.NewSentinelActivities(
				logsDir,
				nucleusExe,
				sentinelExe,
			)

			// Registrar activities con nombres consistentes que usa el workflow
			w.RegisterActivityWithOptions(sentinelAct.LaunchSentinel, activity.RegisterOptions{
				Name: "sentinel.LaunchSentinel",
			})

			w.RegisterActivityWithOptions(sentinelAct.StopSentinel, activity.RegisterOptions{
				Name: "sentinel.StopSentinel",
			})

			w.RegisterActivityWithOptions(sentinelAct.StartOllama, activity.RegisterOptions{
				Name: "sentinel.StartOllama",
			})

			w.RegisterActivityWithOptions(sentinelAct.SeedProfile, activity.RegisterOptions{
				Name: "sentinel.SeedProfile",
			})

			// Activity de onboarding navigate — usa SentinelClient.RouteToProfile() directo
			w.RegisterActivityWithOptions(sentinelAct.SendOnboardingNavigateActivity, activity.RegisterOptions{
				Name: "sentinel.SendOnboardingNavigate",
			})

			// Activity de vault status — usada por VaultStatusWorkflow (system_workflows.go).
			// Reusa el mismo cliente TCP sentinelClientActivity que SendOnboardingNavigate.
			w.RegisterActivityWithOptions(sentinelAct.QueryVaultStatusActivity, activity.RegisterOptions{
				Name: "brain.QueryVaultStatus",
			})

			// Registrar mandate activities (hooks post-launch)
			w.RegisterActivity(mandates.RunPostLaunchHooksActivity)

			// Registrar activity de system health (hooks periódicos de monitoreo)
			w.RegisterActivity(mandates.RunSystemHealthActivity)

			// Registrar activity de profile_disconnected
			// Invocada por brain_poller cuando Brain emite PROFILE_DISCONNECTED.
			w.RegisterActivity(mandates.RunProfileDisconnectedHooksActivity)

			logger.Success("✅ Activities registradas")

			// ── Worker dedicado a mandate-orchestration ──────────────────────
			// MandateGenesisBuildWorkflow (y su child MandateExecutionWorkflow)
			// arrancan siempre con TaskQueue "mandate-orchestration" (hardcoded
			// en temporal_client_addition.go y mandate_genesis_build_workflow.go).
			// El worker principal solo escucha `taskQueue` (profile-orchestration
			// por default) — sin este worker separado, esos workflows quedan
			// disparados en Temporal sin nadie que los ejecute.
			mandateWorker := NewWorker(temporalClient.GetClient(), "mandate-orchestration")
			mandateWorker.RegisterWorkflow(temporalworkflows.MandateGenesisBuildWorkflow)
			mandateWorker.RegisterWorkflow(temporalworkflows.MandateExecutionWorkflow)
			mandateWorker.RegisterActivity(activities.ScaffoldDomainActivity)
			mandateWorker.RegisterActivity(activities.PublishMandateEventActivity)
			// IngestReceptionActivity — CAMPO NUEVO esta sesión (Fase 1 real,
			// ver mandate_genesis_activities.go). Sin este registro, Fase 1
			// fallaría en runtime con "unable to find activity type" apenas
			// MandateGenesisBuildWorkflow la invocara — mismo síntoma que ya
			// tienen SignMandateActivity/PersistHumanSyncActivity, que el
			// workflow también invoca (fases sign/validate) pero que NO están
			// registradas acá — gap preexistente, no introducido en este
			// cambio, señalado y no tocado porque queda fuera del alcance de
			// Fase 1.
			mandateWorker.RegisterActivity(activities.IngestReceptionActivity)
			// Excepción acotada Blocker 1/2-UI: wiring exclusivo de Human Sync
			// y firma. No registra ni activa los adaptadores BSIP.
			registerMandateGenesisSignatureActivities(mandateWorker)
			registerGravityActivities(mandateWorker)

			if err := mandateWorker.Start(); err != nil {
				logger.Error("Fallo al iniciar mandate worker: %v", err)
				os.Exit(1)
			}
			logger.Success("✅ Mandate worker iniciado (task queue: mandate-orchestration)")
			// ── fin worker mandate-orchestration ──────────────────────────────

			// Iniciar worker
			logger.Info("Iniciando worker...")
			if err := w.Start(); err != nil {
				logger.Error("Fallo al iniciar worker: %v", err)
				os.Exit(1)
			}

			logger.Success("✅ Worker iniciado exitosamente")

			// Lanzar Brain Poller
			// Se conecta a Brain TCP como cliente CLI y escucha broadcasts de
			// PROFILE_DISCONNECTED. Cuando recibe uno, dispara RunEvent("profile_disconnected")
			// que ejecuta 00_notify_temporal.py → nucleus synapse shutdown <profile_id>.
			// El contexto cancelable garantiza que el poller para cuando el worker para.
			go activities.StartBrainPoller(ctx, activities.BrainPollerConfig{
				LogsDir:    logsDir,
				NucleusBin: nucleusExe,
			})
			logger.Info("🔌 Brain poller started (listening for PROFILE_DISCONNECTED)")

			// Asegurar Schedule de system health — crea si no existe, actualiza si
			// el intervalo en settings.json cambió desde la última vez.
			// Nunca falla si el schedule ya existe — el worker nuevo lo adopta.
			go func() {
				// Breve delay para que el worker esté completamente listo y los
				// pollers estén registrados en Temporal antes de que el schedule
				// dispare el próximo tick.
				time.Sleep(2 * time.Second)

				intervalSec := c.Settings.Health.IntervalSeconds
				if intervalSec <= 0 {
					intervalSec = 60
				}

				if err := bootstrap.EnsureSystemHealthSchedule(ctx, temporalClient.GetClient(), intervalSec); err != nil {
					logger.Warning("⚠️  Failed to ensure system health schedule: %v", err)
				} else {
					logger.Success("✅ System health schedule active (every %ds)", intervalSec)
				}
			}()

			// Escribir capabilities registry — leído por `nucleus workers list`
			historyWorkersDir := filepath.Join(filepath.Dir(c.Paths.LogsDir), "history", "workers")
			if err := os.MkdirAll(historyWorkersDir, 0755); err != nil {
				logger.Warning("⚠️  Failed to create history/workers dir: %v", err)
			}
			writeWorkerCapabilities(historyWorkersDir, taskQueue,
				[]string{
					"ProfileLifecycleWorkflow",
					"RecoveryFlowWorkflow",
					"StartOllamaWorkflow",
					"VaultStatusWorkflow",
					"ShutdownAllWorkflow",
					"SeedWorkflow",
					"OnboardingWorkflow",
					"SystemHealthWorkflow",
					"MandateGenesisBuildWorkflow",
					"MandateExecutionWorkflow",
				},
				[]string{
					"sentinel.LaunchSentinel",
					"sentinel.StopSentinel",
					"sentinel.StartOllama",
					"sentinel.SeedProfile",
					"sentinel.SendOnboardingNavigate",
					"brain.QueryVaultStatus",
					"RunPostLaunchHooksActivity",
					"RunSystemHealthActivity",
					"RunProfileDisconnectedHooksActivity",
					"ScaffoldDomainActivity",
					"PublishMandateEventActivity",
					"resolveActiveGravityActivity",
				},
			)

			logger.Info("Escuchando en task queue: %s", taskQueue)
			logger.Info("Presione Ctrl+C para detener")

			// Esperar señal de interrupción
			sigChan := make(chan os.Signal, 1)
			signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)

			<-sigChan
			logger.Info("Señal de interrupción recibida, deteniendo worker...")

			// Cancelar el contexto del worker — para el brain_poller y otras goroutines
			cancel()

			w.Stop()
			mandateWorker.Stop()
			logger.Success("✅ Worker detenido exitosamente")
		},
	}

	cmd.Flags().StringVarP(&taskQueue, "task-queue", "q", "profile-orchestration", "Task queue de Temporal")

	return cmd
}
