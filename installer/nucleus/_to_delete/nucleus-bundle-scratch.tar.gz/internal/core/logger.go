package core

import (
	"encoding/json"
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

// ============================================================================
// LOGGER - Maneja logs estructurados (archivo + consola)
// ============================================================================

type Logger struct {
	file       *os.File
	logger     *log.Logger
	isJSONMode bool
	silentMode bool
	mu         sync.Mutex
	category   string
}

// InitLogger crea un logger que escribe a archivo y consola.
// extraCategories permite registrar el stream en categorías adicionales
// (e.g. "synapse" para nucleus_synapse, que pertenece a ["nucleus", "synapse"]).
func InitLogger(paths *Paths, category string, jsonMode bool, extraCategories ...string) (*Logger, error) {
	targetDir := filepath.Join(paths.LogsDir, "nucleus")
	if err := os.MkdirAll(targetDir, 0755); err != nil {
		return nil, fmt.Errorf("error creando directorio %s: %w", targetDir, err)
	}

	now := time.Now()
	logFileName := fmt.Sprintf("nucleus_%s_%s.log", strings.ToLower(category), now.Format("20060102"))
	logPath := filepath.Join(targetDir, logFileName)

	file, err := os.OpenFile(logPath, os.O_CREATE|os.O_RDWR|os.O_APPEND, 0666)
	if err != nil {
		return nil, fmt.Errorf("error al abrir log %s: %w", logPath, err)
	}

	if file == nil {
		return nil, fmt.Errorf("file handle es nil después de OpenFile")
	}

	// ✅ DECISIÓN ÚNICA DE ROUTING
	var consoleWriter io.Writer
	if jsonMode {
		// Modo JSON: logs van a stderr para no contaminar stdout
		consoleWriter = os.Stderr
	} else {
		// Modo normal: logs van a stdout
		consoleWriter = os.Stdout
	}

	dest := io.MultiWriter(consoleWriter, file)
	l := log.New(dest, "", log.Ldate|log.Ltime)

	icon := getNucleusIcon(category)

	logger := &Logger{
		file:       file,
		logger:     l,
		isJSONMode: jsonMode,
		silentMode: false,
		category:   category,
	}

	// Banners de sesión son metadata del archivo de log, no output del proceso.
	// En modo JSON se escriben SOLO al archivo para no contaminar ningún fd de consola
	// (ni stdout ni stderr). En modo interactivo se emiten normalmente via MultiWriter.
	banner := fmt.Sprintf("======================================== [%s] Logging session started ========================================", category)
	if jsonMode {
		fmt.Fprintf(file, "%s %s\n", time.Now().Format("2006/01/02 15:04:05"), banner)
		file.Sync()
	} else {
		logger.logger.Printf("%s", banner)
		logger.Flush()
	}

	// Construir slice de categorías: siempre incluye "nucleus" + extras
	categories := append([]string{"nucleus"}, extraCategories...)

	// Registrar stream en telemetry
	tm := GetTelemetryManager(paths.LogsDir, paths.LogsDir)
	streamID := "nucleus_" + strings.ToLower(category)
	streamLabel := icon + " " + category
	description := getNucleusStreamDescription(category)
	tm.RegisterStream(streamID, streamLabel, 2, categories, description, "nucleus", filepath.ToSlash(logPath))

	return logger, nil
}

func getNucleusIcon(category string) string {
	switch category {
	case "SYSTEM":
		return "🛠️"
	case "GOVERNANCE":
		return "⚖️"
	case "TEAM":
		return "👥"
	case "VAULT":
		return "🔐"
	case "SYNC":
		return "🔄"
	case "ORCHESTRATION":
		return "🕸️"
	case "ANALYTICS":
		return "📊"
	case "TEMPORAL":
		return "⏱️"
	case "SYNAPSE":
		return "🔗"
	case "SERVICE":
		return "⚙️"
	case "WORKER":
		return "👷"
	case "MANDATE":
		return "📋"
	case "BRAIN_POLLER":
		return "🔌"
	case "TELEMETRY":
		return "📡"
	default:
		return "⚙️"
	}
}

func getNucleusStreamDescription(category string) string {
	switch category {
	case "SYSTEM":
		return "Nucleus system log — captures initialization, configuration and system-level events"
	case "GOVERNANCE":
		return "Nucleus governance log — tracks policy enforcement and access control decisions"
	case "TEAM":
		return "Nucleus team log — records team management operations"
	case "VAULT":
		return "Nucleus vault log — captures credential and secret management operations"
	case "SYNC":
		return "Nucleus sync log — tracks synchronization operations and state reconciliation"
	case "ORCHESTRATION":
		return "Nucleus orchestration log — captures workflow coordination and task dispatch"
	case "ANALYTICS":
		return "Nucleus analytics log — records metrics collection and reporting events"
	case "TEMPORAL":
		return "Nucleus temporal log — captures Temporal workflow engine interactions"
	case "SYNAPSE":
		return "Synapse orchestration log — records the full launch chain for a browser profile"
	case "MANDATE":
		return "Nucleus mandate log — captures hook execution and mandate orchestration events"
	case "BRAIN_POLLER":
		return "Nucleus brain_poller log — captures Brain TCP connection lifecycle, PROFILE_DISCONNECTED events received, and hook dispatch results"
	case "TELEMETRY": // ← NUEVO
		return "Nucleus telemetry log — captures all reads, writes, errors, parse failures and lock issues related to telemetry.json"
	default:
		return fmt.Sprintf("Nucleus %s log", strings.ToLower(category))
	}
}

func (l *Logger) SetSilentMode(e bool) {
	l.mu.Lock()
	defer l.mu.Unlock()
	l.silentMode = e
	l.reconfigure()
}

// SetJSONMode reconfigures the logger to route console output to stderr (JSON mode)
// or stdout (interactive mode). Call this after InitLogger if the JSON flag is global.
func (l *Logger) SetJSONMode(enabled bool) {
	l.mu.Lock()
	defer l.mu.Unlock()
	l.isJSONMode = enabled
	l.reconfigure()
}

func (l *Logger) reconfigure() {
	var dest io.Writer

	if l.silentMode {
		// Modo silencioso: solo archivo
		dest = l.file
	} else {
		// ✅ Decisión según modo JSON (configurado en Init)
		var consoleWriter io.Writer
		if l.isJSONMode {
			consoleWriter = os.Stderr
		} else {
			consoleWriter = os.Stdout
		}
		dest = io.MultiWriter(consoleWriter, l.file)
	}

	if l.logger != nil {
		l.logger.SetOutput(dest)
	}
}

// Flush fuerza la escritura de logs al disco
func (l *Logger) Flush() error {
	l.mu.Lock()
	defer l.mu.Unlock()

	if l.file != nil {
		return l.file.Sync()
	}
	return nil
}

func (l *Logger) Info(f string, v ...any) {
	if l.logger == nil {
		return
	}
	l.logger.Printf("[INFO] "+f, v...)
}

func (l *Logger) Error(f string, v ...any) {
	if l.logger == nil {
		return
	}
	l.logger.Printf("[ERROR] "+f, v...)
	l.Flush() // Errores se escriben inmediatamente
}

func (l *Logger) Warning(f string, v ...any) {
	if l.logger == nil {
		return
	}
	l.logger.Printf("[WARNING] "+f, v...)
	l.Flush()
}

func (l *Logger) Success(f string, v ...any) {
	if l.logger == nil {
		return
	}
	l.logger.Printf("[SUCCESS] "+f, v...)
	l.Flush()
}

func (l *Logger) Debug(f string, v ...any) {
	if l.logger == nil {
		return
	}
	l.logger.Printf("[DEBUG] "+f, v...)
}

func (l *Logger) Close() error {
	l.mu.Lock()
	defer l.mu.Unlock()

	if l.file != nil {
		banner := fmt.Sprintf("======================================== [%s] Logging session ended ========================================", l.category)
		if l.isJSONMode {
			fmt.Fprintf(l.file, "%s %s\n", time.Now().Format("2006/01/02 15:04:05"), banner)
		} else {
			l.logger.Printf("%s", banner)
		}
		l.file.Sync()

		err := l.file.Close()
		l.file = nil
		l.logger = nil
		return err
	}
	return nil
}

// ============================================================================
// OUTPUT HELPERS - Resultados finales de comandos
// ============================================================================

// OutputJSON escribe JSON a stdout (para --json flag)
func (l *Logger) OutputJSON(data interface{}) error {
	bytes, err := json.MarshalIndent(data, "", "  ")
	if err != nil {
		return fmt.Errorf("error marshaling JSON: %w", err)
	}

	// ✅ JSON SIEMPRE a stdout, independiente del logger
	fmt.Fprintln(os.Stdout, string(bytes))
	return nil
}

// OutputResult maneja el resultado final según el modo
func (l *Logger) OutputResult(jsonData interface{}, interactiveMessage string) error {
	if l.isJSONMode {
		return l.OutputJSON(jsonData)
	} else {
		// En modo interactivo, usa el mismo canal que los logs (stdout)
		fmt.Fprintln(os.Stdout, interactiveMessage)
		return nil
	}
}

// ============================================================================
// SERVICE LOGGER
// ============================================================================

// InitServiceLogger crea un logger para el servicio background de Nucleus.
// Escribe en logs/nucleus/service/nucleus_service_YYYYMMDD.log (rotación diaria).
func InitServiceLogger(paths *Paths, jsonMode bool) (*Logger, error) {
	targetDir := filepath.Join(paths.LogsDir, "nucleus", "service")
	if err := os.MkdirAll(targetDir, 0755); err != nil {
		return nil, fmt.Errorf("error creando directorio %s: %w", targetDir, err)
	}

	now := time.Now()
	logFileName := fmt.Sprintf("nucleus_service_%s.log", now.Format("20060102"))
	logPath := filepath.Join(targetDir, logFileName)

	file, err := os.OpenFile(logPath, os.O_CREATE|os.O_RDWR|os.O_APPEND, 0666)
	if err != nil {
		return nil, fmt.Errorf("error al abrir log %s: %w", logPath, err)
	}

	var consoleWriter io.Writer
	if jsonMode {
		consoleWriter = os.Stderr
	} else {
		consoleWriter = os.Stdout
	}

	dest := io.MultiWriter(consoleWriter, file)
	l := log.New(dest, "", log.Ldate|log.Ltime)

	logger := &Logger{
		file:       file,
		logger:     l,
		isJSONMode: jsonMode,
		silentMode: false,
		category:   "SERVICE",
	}

	serviceBanner := "======================================== [SERVICE] Logging session started ========================================"
	if jsonMode {
		fmt.Fprintf(file, "%s %s\n", time.Now().Format("2006/01/02 15:04:05"), serviceBanner)
		file.Sync()
	} else {
		logger.logger.Printf("%s", serviceBanner)
		logger.Flush()
	}

	tm := GetTelemetryManager(paths.LogsDir, paths.LogsDir)
	tm.RegisterStream(
		"nucleus_service",
		"⚙️ NUCLEUS SERVICE",
		2,
		[]string{"nucleus"},
		"Nucleus background service log — captures service lifecycle, health checks and daemon events",
		"nucleus",
		filepath.ToSlash(logPath),
	)

	return logger, nil
}

// ============================================================================
// WORKER MANAGER LOGGER
// ============================================================================

// InitWorkerManagerLogger crea un logger para el pool de workers de Nucleus.
// Escribe en logs/nucleus/worker/nucleus_worker_manager_YYYYMMDD.log.
func InitWorkerManagerLogger(paths *Paths, jsonMode bool) (*Logger, error) {
	targetDir := filepath.Join(paths.LogsDir, "nucleus", "worker")
	if err := os.MkdirAll(targetDir, 0755); err != nil {
		return nil, fmt.Errorf("error creando directorio %s: %w", targetDir, err)
	}

	now := time.Now()
	// ✅ Fix Issue #2: prefijo nucleus_ requerido por spec (executable_module_timestamp.log)
	logFileName := fmt.Sprintf("nucleus_worker_manager_%s.log", now.Format("20060102"))
	logPath := filepath.Join(targetDir, logFileName)

	file, err := os.OpenFile(logPath, os.O_CREATE|os.O_RDWR|os.O_APPEND, 0666)
	if err != nil {
		return nil, fmt.Errorf("error al abrir log %s: %w", logPath, err)
	}

	var consoleWriter io.Writer
	if jsonMode {
		consoleWriter = os.Stderr
	} else {
		consoleWriter = os.Stdout
	}

	dest := io.MultiWriter(consoleWriter, file)
	l := log.New(dest, "", log.Ldate|log.Ltime)

	logger := &Logger{
		file:       file,
		logger:     l,
		isJSONMode: jsonMode,
		silentMode: false,
		category:   "WORKER",
	}

	workerBanner := "======================================== [WORKER MANAGER] Logging session started ========================================"
	if jsonMode {
		fmt.Fprintf(file, "%s %s\n", time.Now().Format("2006/01/02 15:04:05"), workerBanner)
		file.Sync()
	} else {
		logger.logger.Printf("%s", workerBanner)
		logger.Flush()
	}

	tm := GetTelemetryManager(paths.LogsDir, paths.LogsDir)
	tm.RegisterStream(
		"nucleus_worker_manager",
		"👷 WORKER MANAGER",
		2,
		[]string{"nucleus"},
		"Nucleus worker manager log — tracks worker pool lifecycle, task assignment and completion",
		"nucleus",
		filepath.ToSlash(logPath),
	)

	return logger, nil
}

// ============================================================================
// TEMPORAL LOGGER ADAPTER
// ============================================================================

// TemporalLogger adapta nuestro Logger al interface de Temporal SDK
type TemporalLogger struct {
	logger *Logger
}

// InitTemporalLogger crea un logger específico para Temporal
func InitTemporalLogger(paths *Paths, jsonMode bool) (*TemporalLogger, error) {
	logger, err := InitLogger(paths, "TEMPORAL", jsonMode)
	if err != nil {
		return nil, err
	}

	return &TemporalLogger{logger: logger}, nil
}

// Debug implements Temporal's logger interface
func (tl *TemporalLogger) Debug(msg string, keyvals ...interface{}) {
	tl.logger.Debug("%s %v", msg, keyvals)
}

// Info implements Temporal's logger interface
func (tl *TemporalLogger) Info(msg string, keyvals ...interface{}) {
	tl.logger.Info("%s %v", msg, keyvals)
}

// Warn implements Temporal's logger interface
func (tl *TemporalLogger) Warn(msg string, keyvals ...interface{}) {
	tl.logger.Warning("%s %v", msg, keyvals)
}

// Error implements Temporal's logger interface
func (tl *TemporalLogger) Error(msg string, keyvals ...interface{}) {
	tl.logger.Error("%s %v", msg, keyvals)
}